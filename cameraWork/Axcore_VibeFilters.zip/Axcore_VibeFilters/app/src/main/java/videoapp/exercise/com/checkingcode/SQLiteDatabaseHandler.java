package videoapp.exercise.com.checkingcode;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.LinkedList;
import java.util.List;

public class SQLiteDatabaseHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "SongsDB2";
    private static final String TABLE_NAME = "Songs";
    private static final String KEY_SONG_NAME = "name";
    private static final String KEY_SONG_URI = "uri";
    private static final String[] COLUMNS = { KEY_SONG_NAME, KEY_SONG_URI };

    public SQLiteDatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
//        db = this.getWritableDatabase();
        String CREATION_TABLE = "CREATE TABLE Songs ( "
                + "name TEXT, "
                + "uri TEXT)";
        db.execSQL(CREATION_TABLE);
//        dropTable();
//        createTable();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // you can implement here migration process
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        this.onCreate(db);
    }

//    public void deleteOne(Song song) {
//        // Get reference to writable DB
//        SQLiteDatabase db = this.getWritableDatabase();
//        db.delete(TABLE_NAME, "id = ?", new String[] { String.valueOf(getSong() });
//        db.close();
//    }

    public Song getSong(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, // a. table
                COLUMNS, // b. column names
                " id = ?", // c. selections
                new String[] { String.valueOf(id) }, // d. selections args
                null, // e. group by
                null, // f. having
                null, // g. order by
                null); // h. limit

        if (cursor != null)
            cursor.moveToFirst();

        Song song = new Song(cursor.getString(0),cursor.getString(1));
//        song.setSongName(cursor.getString(0));
//        song.setSongUri(cursor.getString(1));
        return song;
    }

    public List<Song> allSongs() {
        String songName = "";
        String songUri = "";
        List<Song> songs = new LinkedList<Song>();

        Cursor cursor = this.getReadableDatabase().query(
                TABLE_NAME, new String[] { COLUMNS[0],COLUMNS[1]},
                null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                songName = cursor.getString(0);
                songUri = cursor.getString(1);
                Log.e("sn","sname" + songName);
                Log.e("su","suri" + songUri);
                Song song = new Song(songName,songUri);
                songs.add(song);
            } while (cursor.moveToNext());
        }

        cursor.close();
//        return songs;
//
//        List<Song> songs = new LinkedList<Song>();
//        String query = "SELECT  * FROM " + TABLE_NAME;
//        SQLiteDatabase db = this.getReadableDatabase();
//        Cursor cursor = db.rawQuery(query, null);
//        Song song = null;
//
//        if (cursor.moveToFirst()) {
//            do {
//                song = new Song();
//                song.setName(cursor.getString(0));
//                song.setUri(cursor.getString(1));
//                songs.add(song);
//            } while (cursor.moveToNext());
//        }
        return songs;
    }

    public void addSong(Song song) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_SONG_NAME, song.getName());
        Log.d("name",": " + song.getName());
        Log.d("uri",": " + song.getUri());
        values.put(KEY_SONG_URI, song.getUri());
        // insert
        db.insert(TABLE_NAME,null, values);
        db.close();
    }

//    public int updatePlayer(Song song) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues values = new ContentValues();
//        values.put(KEY_SONG_NAME, song.getSongName());
//        values.put(KEY_SONG_URI, song.getSongUri());
//
//        int i = db.update(TABLE_NAME, // table
//                values, // column/value
//                "id = ?", // selections
//                new String[] { String.valueOf(song.getId()) });
//
//        db.close();
//
//        return i;
//    }
    public int numberOfColumns() {
        int result = 0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_NAME, null, null, null, null, null,
                    null);
            result = cursor.getColumnCount();
            if (result < 0) {
                result = 0;
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return result;
    }

    public void dropTable(){
        Cursor cursor = null;
        SQLiteDatabase db = this.getWritableDatabase();
        String DROP_TABLE = "DROP TABLE Songs";
        db.execSQL(DROP_TABLE);
    }
    public void createTable(){
        SQLiteDatabase db = this.getWritableDatabase();
        String CREATION_TABLE = "CREATE TABLE Songs ( "
                + "name TEXT, "
                + "uri TEXT)";
        db.execSQL(CREATION_TABLE);
    }

    public Boolean checkDataAlreadyExistsorNot(String name){
        String songName = "";
        Boolean flag = false;
        Cursor cursor = this.getReadableDatabase().query(
                TABLE_NAME, new String[] { COLUMNS[0]},
                null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                songName = cursor.getString(0);
                if(songName.equals(name))
                {
                    flag = true;
                    return flag;
                }
                else{
                    flag = false;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return flag;
    }

    public void deleteItemFromList(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME,"name=?",new String[]{name});
    }
}