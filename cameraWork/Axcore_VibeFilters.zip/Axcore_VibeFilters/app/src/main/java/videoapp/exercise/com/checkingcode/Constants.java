package videoapp.exercise.com.checkingcode;

import android.app.Activity;
import android.content.res.Resources;
import android.net.Uri;

public class Constants{
    static final String[] listContent = {"Beat It","Slave to the rhythm", "Billie Jean","Dont Stop Kill You","Smooth Criminal","Thriller","Bad","Blue Gangsta"};
//  static final String[] listContent = {"Beat It","Slave to the rhythm",};
    static final int[] resID = {R.raw.bad,R.raw.beat_it,R.raw.slave_to_the_rhythm_by_darkchild, R.raw.billie_jean,R.raw.dont_stop_kill_you,R.raw.smooth_criminal,R.raw.thriller,R.raw.blue};
//  static final int[] resID = {R.raw.beat_it,R.raw.billie_jean};
    static final String[] listItemsUserScreen = {"My Sounds","Terms & Conditions","Privacy Policy","My Vibes"};
    static final String[] pathList = {"/camera2VideoImage/","/FadeVideos/","/TrimVideos/","/TrimVideos/"};
    static final String USER_DB_NAME = "userprofile.db";
    public static String USER_TABLE_NAME = "user_table";
    public static String USER_SELECTED_SONG_TABLE_NAME = "user_song";
    public static String USER_SELECTED_SONG_COLUMN_NAME = "song";
    public static final String COLUMN_NAME = "name";
}
