package videoapp.exercise.com.checkingcode;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class IndividualSongsListView extends AppCompatActivity {
    private ListView listView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        Intent intent = getIntent();
        setContentView(R.layout.list_view_individual_songs);
        listView = findViewById(R.id.listViewIdIndividualSongs);
        ListViewAdapterIndividualSongs adapter  = new ListViewAdapterIndividualSongs(this,this);
        listView.setAdapter(adapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // handle arrow click here
        if (item.getItemId() == android.R.id.home) {
            finish(); // close this activity and return to preview activity (if there is any)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(ListViewAdapterIndividualSongs.mp!=null)
        ListViewAdapterIndividualSongs.mp.stop();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(ListViewAdapterIndividualSongs.mp!=null)
        ListViewAdapterIndividualSongs.mp.stop();
    }
}
