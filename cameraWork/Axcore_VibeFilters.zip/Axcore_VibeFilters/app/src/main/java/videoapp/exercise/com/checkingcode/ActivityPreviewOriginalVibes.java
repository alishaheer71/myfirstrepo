package videoapp.exercise.com.checkingcode;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.SurfaceTexture;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.LoadBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegNotSupportedException;

import java.io.File;
import java.io.IOException;

public class ActivityPreviewOriginalVibes  extends Activity implements TextureView.SurfaceTextureListener , View.OnClickListener {

    private MediaPlayer mMediaPlayer;
    private String fileName;
    TextureView textureView;
    ImageButton imgBtnBack;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        ListViewAdapterIndividualSongs.intPosition = -1;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview_original_vibes);

//enable back button in activity
        initView();

        Intent intent = getIntent();
        fileName = intent.getStringExtra("FileName");
//        fileName = "/storage/emulated/0/Movies/originalVibe/video1.mp4";

        Log.d("filename",fileName);
        imgBtnBack.setOnClickListener(this);

    }

    private void initView() {
        textureView = findViewById(R.id.textureViewPreviewOriginalVibes);
        textureView.setSurfaceTextureListener(this);
        imgBtnBack = findViewById(R.id.backImgBtnIdOriginalVibes);
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i1) {
        Surface s = new Surface(surfaceTexture);
        try {
            mMediaPlayer = new MediaPlayer();
            mMediaPlayer.setDataSource(fileName);
            mMediaPlayer.setSurface(s);
            mMediaPlayer.prepare();
            mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mMediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mediaPlayer) {
                    mediaPlayer.start();
                }
            });
            mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    mMediaPlayer.start();
                }
            });
        } catch (IllegalArgumentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SecurityException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalStateException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i1) {

    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        return false;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.backImgBtnIdOriginalVibes: {
                finish();
                break;
            }
            default: {
                Log.e("default", "default is running");
            }
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopPlaying(mMediaPlayer);
    }

    private void stopPlaying(MediaPlayer mediaPlayer) {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
    }
}

