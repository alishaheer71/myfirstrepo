package videoapp.exercise.com.checkingcode;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.media.CamcorderProfile;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.Size;
import android.util.SparseIntArray;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.coremedia.iso.boxes.Container;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.MultiProcessor;
import com.google.android.gms.vision.Tracker;
import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.FaceDetector;
import com.googlecode.mp4parser.authoring.Movie;
import com.googlecode.mp4parser.authoring.Track;
import com.googlecode.mp4parser.authoring.builder.DefaultMp4Builder;
import com.googlecode.mp4parser.authoring.container.mp4.MovieCreator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import videoapp.exercise.com.checkingcode.SaifWork.FaceTracker;
import videoapp.exercise.com.checkingcode.ui.camera.CameraSourcePreview;
import videoapp.exercise.com.checkingcode.ui.camera.GraphicOverlay;

public class MainActivity extends AppCompatActivity{

    String filename;
    MediaExtractor audioExtractor = null;
    private ImageButton mRecordImageButton;
    private static final String TAG = "Camera2VideoActivity";

    private static final int REQUEST_CAMERA_PERMISSION_RESULT = 0;
    private static final int REQUEST_WRITE_EXTERNAL_STORAGE_PERMISSION_RESULT = 1;
    private static final int STATE_PREVIEW = 0;
    private static final int STATE_WAIT_LOCK = 1;
    private int mCaptureState = STATE_PREVIEW;
    public static TextureView mTextureView;
    Boolean flag=false;
    private TextView tvSelectSong;
    private ImageButton switchCameraBtn;



    private HandlerThread mBackgroundHandlerThread;
    private Handler mBackgroundHandler;
    private String mCameraId;
    private Size mPreviewSize;
    private Size mVideoSize;
    private Size mImageSize;
    private ImageReader mImageReader;


    private MediaRecorder mMediaRecorder;
    private Chronometer mChronometer;
    private int mTotalRotation;
    private CameraCaptureSession mPreviewCaptureSession;

    private final ImageReader.OnImageAvailableListener mOnImageAvailableListener = new
            ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader reader) {
                    mBackgroundHandler.post(new ImageSaver(reader.acquireLatestImage()));
                }
            };

    public final static ArrayList<String> audioName = new ArrayList<>();
    public final static ArrayList<String> audioLocation = new ArrayList<>();
    private Util util= new Util();
    private TextureView.SurfaceTextureListener mSurfaceTextureListener = new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            if(util.flag){
                mCameraId = String.valueOf(1); //front camera
                //setupCamera(mTextureView.getWidth(), mTextureView.getHeight());
                setupCamera();
                startCameraSource();
                //connectCamera();
            }else{
                util.flag = false;
                mCameraId = String.valueOf(1); //back camera
                //setupCamera(mTextureView.getWidth(), mTextureView.getHeight());
                setupCamera();
                startCameraSource();
                //connectCamera();
            }
            switchCameraBtn = (ImageButton) findViewById(R.id.switchCameraBtnId);

            switchCameraBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    mIsFrontFacing = !mIsFrontFacing;

                    if (mCameraSource != null) {
                        mCameraSource.release();
                        mCameraSource = null;
                    }

                    setupCamera();
                    startCameraSource();

//
//
//                    if(util.cameraFacing()){
////                        switchBtnClicked = false;
//                        util.flag = false;
//                        mCameraId = String.valueOf(0); //back camera
//                           if(mCameraDevice!=null)
//                             mCameraDevice.close();
//                        closeCamera();
//                        //setupCamera(mTextureView.getWidth(), mTextureView.getHeight());
//                        setupCamera();
//                        connectCamera();
//                        Log.e("click part","false");
//                    }
//                    else{
//                        util.flag = true;
//                        mCameraId = String.valueOf(1); //front camera
//                            if(mCameraDevice!=null)
//                               mCameraDevice.close();
//                        closeCamera();
//                        //setupCamera(mTextureView.getWidth(), mTextureView.getHeight());
//                        setupCamera();
//                        connectCamera();
//                        Log.e("click part","true");
//                    }
               }
            });
        }
        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {

        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
            return false;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surface) {

        }
    };

    private CameraDevice mCameraDevice;
    private CameraDevice.StateCallback mCameraDeviceStateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(CameraDevice camera) {
            mCameraDevice = camera;
            mMediaRecorder = new MediaRecorder();
            if(mIsRecording) {
                try {
                    createVideoFileName();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                startRecord();
                mMediaRecorder.start();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mChronometer.setBase(SystemClock.elapsedRealtime());
                        Log.e("base : ","base: " + mChronometer.getBase());
                        mChronometer.setVisibility(View.VISIBLE);
                        mChronometer.start();
                    }
                });
            } else {
                startPreview();
           }
            // Toast.makeText(getApplicationContext(),
            //         "Camera connection made!", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onDisconnected(CameraDevice camera) {
            camera.close();
            mCameraDevice = null;
        }

        @Override
        public void onError(CameraDevice camera, int error) {
            camera.close();
            mCameraDevice = null;
        }

    };


    private class ImageSaver implements Runnable {

        private final Image mImage;

        public ImageSaver(Image image) {
            mImage = image;
        }

        @Override
        public void run() {
            ByteBuffer byteBuffer = mImage.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[byteBuffer.remaining()];
            byteBuffer.get(bytes);

            FileOutputStream fileOutputStream = null;
            try {
                fileOutputStream = new FileOutputStream(mImageFileName);
                fileOutputStream.write(bytes);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                mImage.close();

                Intent mediaStoreUpdateIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                mediaStoreUpdateIntent.setData(Uri.fromFile(new File(mImageFileName)));
                sendBroadcast(mediaStoreUpdateIntent);

                if (fileOutputStream != null) {
                    try {
                        fileOutputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private CameraCaptureSession.CaptureCallback mPreviewCaptureCallback = new
            CameraCaptureSession.CaptureCallback() {

                private void process(CaptureResult captureResult) {
                    switch (mCaptureState) {
                        case STATE_PREVIEW:
                            // Do nothing
                            break;
                        case STATE_WAIT_LOCK:
                            mCaptureState = STATE_PREVIEW;
                            Integer afState = captureResult.get(CaptureResult.CONTROL_AF_STATE);
                            if(afState == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED ||
                                    afState == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED) {
                                Toast.makeText(getApplicationContext(), "AF Locked!", Toast.LENGTH_SHORT).show();
                                startStillCaptureRequest();
                            }
                            break;
                    }
                }

                @Override
                public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request, TotalCaptureResult result) {
                    super.onCaptureCompleted(session, request, result);

                    process(result);
                }
            };

    private CameraCaptureSession mRecordCaptureSession;
    private CameraCaptureSession.CaptureCallback mRecordCaptureCallback = new
            CameraCaptureSession.CaptureCallback() {

                private void process(CaptureResult captureResult) {
                    switch (mCaptureState) {
                        case STATE_PREVIEW:
                            // Do nothing
                            break;
                        case STATE_WAIT_LOCK:
                            mCaptureState = STATE_PREVIEW;
                            Integer afState = captureResult.get(CaptureResult.CONTROL_AF_STATE);
                            if(afState == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED ||
                                    afState == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED) {
                                Toast.makeText(getApplicationContext(), "AF Locked!", Toast.LENGTH_SHORT).show();
                                startStillCaptureRequest();
                            }
                            break;
                    }
                }

                @Override
                public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request, TotalCaptureResult result) {
                    super.onCaptureCompleted(session, request, result);

                    process(result);
                }
            };

    private CaptureRequest.Builder mCaptureRequestBuilder;

    private ImageButton mStillImageButton;
    private boolean mIsRecording = false;
    private boolean mIsTimelapse = false;

    private File mVideoFolder;
    private String mVideoFileName;
    private File mImageFolder;
    private String mImageFileName;


    private static final int RC_HANDLE_GMS = 9001;
    // permission request codes need to be < 256
    private static final int RC_HANDLE_CAMERA_PERM = 255;

    private CameraSource mCameraSource = null;
    private CameraSourcePreview mPreview;
    private GraphicOverlay mGraphicOverlay;
    private boolean mIsFrontFacing = true;

    private static SparseIntArray ORIENTATIONS = new SparseIntArray();
    static {
        ORIENTATIONS.append(Surface.ROTATION_0, 0);
        ORIENTATIONS.append(Surface.ROTATION_90, 90);
        ORIENTATIONS.append(Surface.ROTATION_180, 180);
        ORIENTATIONS.append(Surface.ROTATION_270, 270);
    }

    private static class CompareSizeByArea implements Comparator<Size> {

        @Override
        public int compare(Size lhs, Size rhs) {
            return Long.signum( (long)(lhs.getWidth() * lhs.getHeight()) -
                    (long)(rhs.getWidth() * rhs.getHeight()));
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final Context context = getApplicationContext();
        super.onCreate(savedInstanceState);
        loadAudioConverter();
        Util.requestPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        Util.requestPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        setContentView(R.layout.activity_main);
        reqCode=0;
        mRecordImageButton = findViewById(R.id.videoOnlineImageButton);

        /**
         * Saif Work Start here
         * */

        if (savedInstanceState != null) {
            mIsFrontFacing = savedInstanceState.getBoolean("IsFrontFacing");
        }


        // Start using the camera if permission has been granted to this app,
        // otherwise ask for permission to use it.
        int rc = ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        if (rc == PackageManager.PERMISSION_GRANTED) {
            setupCamera();
        } else {
            Util.requestPermission((Activity) context,Manifest.permission.CAMERA);
        }
        /*
        * End Here
        * */

        if(flag)
        {
            mRecordImageButton.setVisibility(View.VISIBLE);
        }
        else{
            mRecordImageButton.setVisibility(View.INVISIBLE);
        }
        getSongsIntoList();

        createVideoFolder();
        createImageFolder();

        ImageView ivIconUser = findViewById(R.id.userIconId);
        tvSelectSong = findViewById(R.id.tvSelectSongId);
        mChronometer = findViewById(R.id.chronometer);
        mTextureView = findViewById(R.id.textureView);
        mStillImageButton =  findViewById(R.id.cameraImageButton2);

        mPreview = findViewById(R.id.preview);
        mGraphicOverlay = findViewById(R.id.faceOverlay);


//        mStillImageButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if(!(mIsTimelapse || mIsRecording)) {
//                    checkWriteStoragePermission();
//                }
//                lockFocus();
//            }
//        });
        tvSelectSong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(reqCode==1)
                {
                    Intent intent = new Intent(MainActivity.this,IndividualSongsListView.class);
                    startActivityForResult(intent,1);
                }
//                else if(reqCode==2)
//                {
//                    Intent intent = new Intent(MainActivity.this,SelectedSongsList.class);
//                    startActivityForResult(intent,2);
//                }
                else{ //default functionality
                    Intent intent = new Intent(MainActivity.this,IndividualSongsListView.class);
                    startActivityForResult(intent,1);
                }
            }
        });



        Typeface myfont = Typeface.createFromAsset(getAssets(),"fonts/OpenSans-Semibold.ttf");
        tvSelectSong.setTypeface(myfont);

        ivIconUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,UserInfoScreen.class);
                startActivityForResult(intent,2);
            }
        });

        final int[] count = {0};
        mRecordImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mIsRecording || mIsTimelapse) {
                    mRecordImageButton.setVisibility(View.INVISIBLE);
                    mChronometer.stop();
                    mChronometer.setVisibility(View.INVISIBLE);
                    mIsRecording = false;
                    mIsTimelapse = false;

                    mRecordImageButton.setImageResource(R.mipmap.btn_video_online);

                    // Starting the preview prior to stopping recording which should hopefully
                    // resolve issues being seen in Samsung devices.
                    startPreview();
//                    media plaer release

//                    mplayer.stop();

//                    mMediaRecorder.stop();

                    mMediaRecorder.reset();

                    saveVideoToLocalStorage(mVideoFileName);

                    Intent intent = new Intent(MainActivity.this,TrimVideo.class);
                    intent.putExtra("FileName",mVideoFileName);

                    String width = String.valueOf(mTextureView.getWidth());
                    String height = String.valueOf(mTextureView.getHeight());

                    intent.putExtra("width", width);
                    intent.putExtra("height",height);

                    Log.e("filename","name--" + mVideoFileName);
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                    Toast.makeText(getApplicationContext(),"Video has been saved",Toast.LENGTH_SHORT).show();
                } else{
                    mChronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
                        @Override
                        public void onChronometerTick(Chronometer chronometer) {
                            long time = SystemClock.elapsedRealtime()-mChronometer.getBase();
                            Log.e("time","time: "+time/1000);
                            time = time/1000;
                            Log.e("time","time: "+totalDuration);
                            mRecordImageButton.setVisibility(View.INVISIBLE);
                            if(time==totalDuration)
                            {
                                mChronometer.stop();
                                mChronometer.setVisibility(View.INVISIBLE);
                                mIsRecording = false;
                                mIsTimelapse = false;
                                mRecordImageButton.setImageResource(R.mipmap.play_btn);

                                // Starting the preview prior to stopping recording which should hopefully
                                // resolve issues being seen in Samsung devices.
                                startPreview();
         //                    media plaer release

                                if(mplayer!=null) {
                                    mplayer.stop();
                                 }
                                 if(mMediaRecorder!=null){
                                    try{
                                        mMediaRecorder.stop();
                                    }
                                    catch(Exception e){
                                        Toast.makeText(getApplicationContext(),"exception: " + e,Toast.LENGTH_SHORT);
                                    }
                                    finally {
                                        mMediaRecorder.release();
                                        mMediaRecorder = null;
                                    }
                                 }
//
//                                mMediaRecorder.reset();

                                Log.e("time","time: "+totalDuration);

//                              Log.d("name" , a);
                                filename = mVideoFileName;
                                saveVideoToLocalStorage(mVideoFileName);
                                addAudioToBackgroundOfVideo();
                                stopPlaying(mplayer);

//                                Intent intent = new Intent(MainActivity.this,Activity_Preview.class);
//                                intent.putExtra("FileName",mVideoFileName);
//
//                                String width = String.valueOf(mTextureView.getWidth());
//                                String height = String.valueOf(mTextureView.getHeight());
//
//                                intent.putExtra("width", width);
//                                intent.putExtra("height",height);
//
//                                Log.e("filename","name--" + mVideoFileName);
//                                startActivity(intent);
//                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                            }
                        }
                        private void addAudioToBackgroundOfVideo() {
                            File movieFile = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
                            if(reqCode==1)
                            {
                                audioExtractor = new MediaExtractor();
                                AssetFileDescriptor afdd2 = getResources()
                                        .openRawResourceFd(posUri);
                                try {
                                    audioExtractor.setDataSource(afdd2.getFileDescriptor(), afdd2.getStartOffset(), afdd2.getLength());
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                            }
                            muxing(movieFile);
                         }
                        private int getCountInDirectory(File file){
                            File dir = file; // "/mnt/sdcard/yourfolder"
                            int totalNumFiles = dir.listFiles().length;
                            return totalNumFiles;
                        }

                        private void muxing(File moviesDir) {

                            File fileVibe = new File(moviesDir.getAbsolutePath()+"/originalVibe");
                            mVideoFolder = new File(fileVibe.toString());
                            if(!mVideoFolder.exists()) {
                                mVideoFolder.mkdirs();
                            }
                            int count = getCountInDirectory(fileVibe);

                            Log.e("count","ccc -- " + count);
                            File file = new File(moviesDir.getAbsolutePath()+"/originalVibe"+"/video" + ++count +".mp4");

                            try {
                                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                                file.createNewFile();
                            }catch (Exception e)
                            {
                                Log.d(TAG, "Excep " + e);
                            }
                            String outputFile="";
                            outputFile = file.getAbsolutePath();
                            Log.d(TAG, "Video Output file " + outputFile);

                            MediaExtractor videoExtractor = new MediaExtractor();
                            try{
                                Log.e(":::",":::" + mVideoFileName);
//                                File file1 = new File(moviesDir.getAbsolutePath()+"/Movies2/");
                                videoExtractor.setDataSource(mVideoFileName);
                            }catch(Exception e){
                                Log.d("eror",":: " + e);
                            }

//                            MediaExtractor audioExtractor = null;
                            if(reqCode==1)
                            {
//                                audioExtractor = new MediaExtractor();
//                                AssetFileDescriptor afdd2 = getResources()
//                                        .openRawResourceFd(posUri);
//                                try {
//                                    audioExtractor.setDataSource(afdd2.getFileDescriptor(), afdd2.getStartOffset(), afdd2.getLength());
//                                } catch (IOException e) {
//                                    e.printStackTrace();
//                                }
//
                            }

                            else if(reqCode==2)
                            {
//                                File convertedAudioPath;
////                                convertAudioIntoAACformat();
//                                File wavFile = new File(pos_uri_from_uer_info_screen);
//                                final Boolean[] flag = {false};
//                                IConvertCallback callback = new IConvertCallback() {
//                                    @Override
//                                    public void onSuccess(File convertedFile) {
//                                        removeWorkingDialog();
//                                        Toast.makeText(MainActivity.this, "SUCCESS: " + convertedFile.getPath(), Toast.LENGTH_LONG).show();
//                                        flag[0] = true;
//                                    }
//                                    @Override
//                                    public void onFailure(Exception error) {
//                                        Toast.makeText(MainActivity.this, "ERROR: " + error.getMessage(), Toast.LENGTH_LONG).show();
//                                    }
//
//                                    @Override
//                                    public void onProgress(String message) {
//                                        working_dialog.setCancelable(false);
//                                        showWorkingDialog();
////                                        long timerforprogressbar = 10000;
////                                        new Handler().postDelayed(new Runnable() {
////
////                                            @Override
////                                            public void run() {
////                                                removeWorkingDialog();
////                                            }
////
////                                        }, timerforprogressbar);
//                                    }
//                                };
//                                Toast.makeText(MainActivity.this, "Converting audio file...", Toast.LENGTH_SHORT).show();
//                                convertedAudioPath = AndroidAudioConverter.with(MainActivity.this)
//                                        .setFile(wavFile)
//                                        .setFormat(AudioFormat.AAC)
//                                        .setCallback(callback)
//                                        .convert();
//
//                                audioExtractor = new MediaExtractor();
//                                try {
//                                    audioExtractor.setDataSource(String.valueOf(convertedAudioPath));
//                                } catch (IOException e) {
//                                    e.printStackTrace();
//                                }
                            }
                            Log.d(TAG, "Video Extractor Track Count " + videoExtractor.getTrackCount());
                            Log.d(TAG, "Audio Extractor Track Count " + audioExtractor.getTrackCount());
                            MediaMuxer muxer = null;
                            try {
                                muxer = new MediaMuxer(outputFile, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                            }
                            catch (Exception e){
                                Log.d(TAG, "ExcepMuxer " + e);
                            }
                            MediaFormat videoFormat=null;
                            int videoTrack=0;
                            try {
                                videoExtractor.selectTrack(0);
                                videoFormat = videoExtractor.getTrackFormat(0);
                                videoTrack = muxer.addTrack(videoFormat);
                            } catch (Exception e) {
                                Log.d(TAG, "videoTrack :  " + e);
                            }
                            MediaFormat audioFormat= null;
                            int audioTrack=0;
                            try {
                                audioExtractor.selectTrack(0);
                                audioFormat = audioExtractor.getTrackFormat(0);
                                Log.d(TAG, "Audio Format " + audioFormat.toString());
                                audioTrack = muxer.addTrack(audioFormat);
                            } catch (Exception e){
                                Log.d(TAG, "audioFormat :  " + e);
                            }
//                            Log.d(TAG, "Video Format " + videoFormat.toString());
//                            Log.d(TAG, "Audio Format " + audioFormat.toString());

                            boolean sawEOS = false;
                            int frameCount = 0;
                            int offset = 100;
                            int sampleSize = 256 * 1024;
                            ByteBuffer videoBuf = ByteBuffer.allocate(sampleSize);
                            ByteBuffer audioBuf = ByteBuffer.allocate(sampleSize);
                            MediaCodec.BufferInfo videoBufferInfo = new MediaCodec.BufferInfo();
                            MediaCodec.BufferInfo audioBufferInfo = new MediaCodec.BufferInfo();


                            videoExtractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
                            audioExtractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC);

                            muxer.start();
                            while(!sawEOS){
                                videoBufferInfo.offset = offset;
                                videoBufferInfo.size = videoExtractor.readSampleData(videoBuf, offset);

                                if(videoBufferInfo.size < 0 || audioBufferInfo.size < 0) {
                                    Log.d(TAG, "saw input EOS.");
                                    sawEOS = true;
                                    videoBufferInfo.size = 0;

                                }else {
                                    videoBufferInfo.presentationTimeUs = videoExtractor.getSampleTime();
                                    videoBufferInfo.flags = videoExtractor.getSampleFlags();
                                    muxer.writeSampleData(videoTrack, videoBuf, videoBufferInfo);
                                    videoExtractor.advance();
                                    frameCount++;
                                    Log.d(TAG, "Frame (" + frameCount + ") Video PresentationTimeUs:" + videoBufferInfo.presentationTimeUs + " Flags:" + videoBufferInfo.flags + " Size(KB) " + videoBufferInfo.size / 1024);
                                    Log.d(TAG, "Frame (" + frameCount + ") Audio PresentationTimeUs:" + audioBufferInfo.presentationTimeUs + " Flags:" + audioBufferInfo.flags + " Size(KB) " + audioBufferInfo.size / 1024);
                                }
                            }

                            Toast.makeText(getApplicationContext(), "frame:" + frameCount, Toast.LENGTH_SHORT).show();


                            boolean sawEOS2 = false;
                            int frameCount2 = 0;
                            while (!sawEOS2) {
                                frameCount2++;

                                audioBufferInfo.offset = offset;
                                audioBufferInfo.size = audioExtractor.readSampleData(audioBuf, offset);

                                if (videoBufferInfo.size < 0 || audioBufferInfo.size < 0) {
                                    Log.d(TAG, "saw input EOS.");
                                    sawEOS2 = true;
                                    audioBufferInfo.size = 0;
                                } else {
                                    audioBufferInfo.presentationTimeUs = audioExtractor.getSampleTime();
                                    audioBufferInfo.flags = audioExtractor.getSampleFlags();
                                    muxer.writeSampleData(audioTrack, audioBuf, audioBufferInfo);
                                    audioExtractor.advance();


                                    Log.d(TAG, "Frame (" + frameCount + ") Video PresentationTimeUs:" + videoBufferInfo.presentationTimeUs + " Flags:" + videoBufferInfo.flags + " Size(KB) " + videoBufferInfo.size / 1024);
                                    Log.d(TAG, "Frame (" + frameCount + ") Audio PresentationTimeUs:" + audioBufferInfo.presentationTimeUs + " Flags:" + audioBufferInfo.flags + " Size(KB) " + audioBufferInfo.size / 1024);

                                }
                            }
                            MuxerCallBack muxerCallback=new MuxerCallBack() {
                                @Override
                                public void onSuccess() {
                                    Intent intent = new Intent(MainActivity.this,Activity_Preview.class);
                                    intent.putExtra("FileName",filename);

                                    String width = String.valueOf(mTextureView.getWidth());
                                    String height = String.valueOf(mTextureView.getHeight());

                                    intent.putExtra("width", width);
                                    intent.putExtra("height",height);

                                    Log.e("filename","name--" + mVideoFileName);
                                    startActivity(intent);
                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                                }

                                @Override
                                public void onFailure(Exception error) {
                                    Toast.makeText(getApplicationContext(), "Something went wrong..." , Toast.LENGTH_SHORT).show();
                                }
                            };
                            Toast.makeText(getApplicationContext(), "frame:" + frameCount2, Toast.LENGTH_SHORT).show();
                            muxer.stop();
                            muxer.release();
                            mVideoFileName = file.getAbsolutePath();
                            muxerCallback.onSuccess();
                        }
//                            Log.e("tag","tag" + mVideoFileName + (Constants.resID[0]));
//                            String name =  ffmpeg.mux(mVideoFileName,"/storage/emulated/0/Movies/camera2VideoImage/beat_it.mp3");
//                            Log.e("name" , ""+name);
//                            ffmpeg.loadFFMpegBinary();
//                            ffmpeg.executeAddAudioToVideoCommand(Uri.parse("/storage/emulated/0/Movies/camera2VideoImage/beat_it.mp3"),mVideoFileName);

//                            ffmpeg.loadFFMpegBinary();
//                            ffmpeg.choice = 5;
//                            ffmpeg.selectedVideoUri = Uri.fromFile(new File(mVideoFileName));
//                            if(ffmpeg.selectedVideoUri!=null)
//                                ffmpeg.executeAddAudioToVideoCommand(Uri.parse("/storage/emulated/0/Movies/camera2VideoImage/beat_it.mp3"),mVideoFileName);

                    });
                    mIsRecording = true;
                    mRecordImageButton.setImageResource(R.mipmap.btn_video_busy);
                    checkWriteStoragePermission();
                }
            }
        });

//        mRecordImageButton.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                mIsTimelapse =true;
//                mRecordImageButton.setImageResource(R.mipmap.btn_timelapse);
//                checkWriteStoragePermission();
//                return true;
//            }
//        });
    }
    private ProgressDialog working_dialog;

    private void showWorkingDialog() {
        working_dialog = ProgressDialog.show(MainActivity.this, "","Working please wait...");
        working_dialog.setCancelable(false);
    }

    private void removeWorkingDialog() {
        if (working_dialog != null) {
            working_dialog.dismiss();
            working_dialog = null;
        }
    }
    File convertedAudioPath;
    private Boolean[] convertAudioIntoAACformat() {
        File wavFile = new File(pos_uri_from_uer_info_screen);
        final Boolean[] flag = {false};
        showWorkingDialog();
        IConvertCallback callback = new IConvertCallback() {
            @Override
            public void onSuccess(File convertedFile) {
                removeWorkingDialog();
                Toast.makeText(MainActivity.this, "SUCCESS: " + convertedFile.getPath(), Toast.LENGTH_LONG).show();
                flag[0] = true;
            }
            @Override
            public void onFailure(Exception error) {
                removeWorkingDialog();
                Toast.makeText(MainActivity.this, "ERROR: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
       };
        Toast.makeText(this, "Converting audio file...", Toast.LENGTH_SHORT).show();
        convertedAudioPath = AndroidAudioConverter.with(this)
                .setFile(wavFile)
                .setFormat(AudioFormat.AAC)
                .setCallback(callback)
                .convert();
                return flag;
    }

    private void loadAudioConverter() {
        AndroidAudioConverter.load(this, new ILoadCallback() {
            @Override
            public void onSuccess() {
                // Great!
            }
            @Override
            public void onFailure(Exception error) {
                // FFmpeg is not supported by device
                error.printStackTrace();
            }
        });
    }

    int posUri;
    String pos_uri_from_uer_info_screen="";
    int reqCode = -1;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Toast.makeText(getApplicationContext(),"coming in activity result",Toast.LENGTH_SHORT).show();
        Log.e("inside result","result inside msg");

        if(requestCode==1)
        {
            if(resultCode==1)
            {
                reqCode=1;
                flag = true;
                mRecordImageButton.setVisibility(View.VISIBLE);
//                int pos = ListViewAdapterIndividualSongs.intPosition;
//                stopPlaying(mplayer);
                Log.d("","" + Uri.parse(data.getStringExtra("songUri")));
                tvSelectSong.setText(data.getStringExtra("songName"));
                posUri = Integer.parseInt(data.getStringExtra("songUri"));
                mplayer = MediaPlayer.create(getApplicationContext(), posUri);
                totalDuration = mplayer.getDuration()/1000; // to get total duration in milliseconds
                Log.e("time in second--","OPR : " + totalDuration);
            }
            if(resultCode==RESULT_CANCELED)
            {
                mRecordImageButton.setVisibility(View.INVISIBLE);
                Toast.makeText(getApplicationContext(),"Select Song to enable Record Button",Toast.LENGTH_SHORT).show();
            }
        }
        else if(requestCode==2){
            if(resultCode==2)
            {
                tvSelectSong.setText(data.getStringExtra("songName"));
                pos_uri_from_uer_info_screen = data.getStringExtra("songUri");
                mplayer = MediaPlayer.create(getApplicationContext(), Uri.parse(pos_uri_from_uer_info_screen));
                totalDuration = mplayer.getDuration()/1000; // to get total duration in milliseconds

                reqCode=2;
                File convertedAudioPath;
//                                convertAudioIntoAACformat();
                File wavFile = new File(pos_uri_from_uer_info_screen);

                final Boolean[] flag = {false};
                showWorkingDialog();
                IConvertCallback callback = new IConvertCallback() {
                    @Override
                    public void onSuccess(File convertedFile) {
                        removeWorkingDialog();
                        Toast.makeText(MainActivity.this, "SUCCESS: " + convertedFile.getPath(), Toast.LENGTH_LONG).show();
                        flag[0] = true;
                        mRecordImageButton.setVisibility(View.VISIBLE);
                    }
                    @Override
                    public void onFailure(Exception error) {
                        removeWorkingDialog();
                        Toast.makeText(MainActivity.this, "ERROR SELECTING SONG: " + error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                };
                Toast.makeText(MainActivity.this, "Converting audio file...", Toast.LENGTH_SHORT).show();
                                convertedAudioPath = AndroidAudioConverter.with(MainActivity.this)
                                        .setFile(wavFile)
                                        .setFormat(AudioFormat.AAC)
                                        .setCallback(callback)
                                        .convert();

                                audioExtractor = new MediaExtractor();
                                try {
                                    audioExtractor.setDataSource(String.valueOf(convertedAudioPath));
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                Log.e("time in second--","OPR : " + totalDuration);
            }
        }
        else{
            mRecordImageButton.setVisibility(View.INVISIBLE);
            Toast.makeText(getApplicationContext(),"Nothing is selected",Toast.LENGTH_SHORT).show();
        }
    }

    String urlPosition;
    long totalDuration;
//    @Override
//    protected void onPostResume() {
//        super.onPostResume();
//        MediaPlayer mplayer = null;
//        if(flag){
//            mRecordImageButton.setVisibility(View.VISIBLE);
//        }
//
//        Log.e("coming in  PR","coming in  PR msg");
//        if(ListViewAdapterMainList.check) {
//                Log.e("if tqag===","working");
//                String songname = ListViewAdapterMainList.songName;
//                int urlPosition = ListViewAdapterMainList.songPosition;
//                String songName = songname;
//                mRecordImageButton.setVisibility(View.VISIBLE);
//                stopPlaying(mplayer);
//                String uri = String.valueOf(ListViewAdapterMainList.itemsUri[urlPosition]);
//                mplayer = MediaPlayer.create(getApplicationContext(), Uri.parse(uri));
//                tvSelectSong.setText(songName);
//                totalDuration = mplayer.getDuration()/1000; // to get total duration in milliseconds
//                Log.e("time in second--","OPRInAdapter : " + totalDuration);
//        }
//        else if(ListViewAdapterIndividualSongs.intPosition!=-1){
//            mRecordImageButton.setVisibility(View.VISIBLE);
//            int pos = ListViewAdapterIndividualSongs.intPosition;
//            stopPlaying(mplayer);
//            mplayer = MediaPlayer.create(getApplicationContext(), Constants.resID[ListViewAdapterIndividualSongs.intPosition]);
//            tvSelectSong.setText(Constants.listContent[pos]);
//            totalDuration = mplayer.getDuration()/1000; // to get total duration in milliseconds
//            Log.e("time in second--","OPR : " + totalDuration);
//        }
//        else if(mplayer==null){
//            Toast.makeText(getApplicationContext(),"Select Song to enable Record Button",Toast.LENGTH_SHORT).show();
//            mRecordImageButton.setVisibility(View.INVISIBLE);
//        }
//    }

    private void stopPlaying(MediaPlayer mediaPlayer) {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
    }

    private void saveVideoToLocalStorage(String mVideoFileName) {
        Intent mediaStoreUpdateIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        mediaStoreUpdateIntent.setData(Uri.fromFile(new File(mVideoFileName)));
        sendBroadcast(mediaStoreUpdateIntent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        startBackgroundThread();

        if(mTextureView.isAvailable()){
            //setupCamera();
            startCameraSource();
           // connectCamera();

        } else {
            mTextureView.setSurfaceTextureListener(mSurfaceTextureListener);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CAMERA_PERMISSION_RESULT: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    setupCamera();
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                } else {
                    Toast.makeText(getApplicationContext(),
                            "Application will not run without camera services", Toast.LENGTH_SHORT).show();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }
            case REQUEST_WRITE_EXTERNAL_STORAGE_PERMISSION_RESULT: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if(mIsRecording || mIsTimelapse) {
                    mIsRecording = true;
//                    mRecordImageButton.setImageResource(R.mipmap.btn_video_busy);
                }
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                } else {
                    Toast.makeText(getApplicationContext(),
                            "Application will not run without camera services", Toast.LENGTH_SHORT).show();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }
//            if(requestCode == REQUEST_CAMERA_PERMISSION_RESULT) {
//            if(grantResults[0] != PackageManager.PERMISSION_GRANTED) {
//                Toast.makeText(getApplicationContext(),
//                        "Application will not run without camera services", Toast.LENGTH_SHORT).show();
//            }
//            if(grantResults[1] != PackageManager.PERMISSION_GRANTED) {
//                Toast.makeText(getApplicationContext(),
//                        "Application will not have audio on record", Toast.LENGTH_SHORT).show();
//            }
//        }
//        if(requestCode == REQUEST_WRITE_EXTERNAL_STORAGE_PERMISSION_RESULT) {
//            if(grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                if(mIsRecording || mIsTimelapse) {
//                    mIsRecording = true;
//                    mRecordImageButton.setImageResource(R.mipmap.btn_video_busy);
//                }
//                Toast.makeText(this,
//                        "Permission successfully granted!", Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(this,
//                        "App needs to save video to run", Toast.LENGTH_SHORT).show();
//            }
        }
    }

    @Override
    protected void onPause() {
        closeCamera();

        stopBackgroundThread();

        super.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocas) {
        super.onWindowFocusChanged(hasFocas);
        View decorView = getWindow().getDecorView();
        if(hasFocas) {
            decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        }
    }

    private void setupCamera() {
//        CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
//
//        try {
//            for(String cameraId : cameraManager.getCameraIdList()){
//                CameraCharacteristics cameraCharacteristics = cameraManager.getCameraCharacteristics(cameraId);
//                if(cameraCharacteristics.get(CameraCharacteristics.LENS_FACING) ==
//                        Integer.parseInt(mCameraId)){
//                    int max_count = cameraCharacteristics.get(
//                            CameraCharacteristics.STATISTICS_INFO_MAX_FACE_COUNT);
//                    Log.e("max" , "" + max_count);
//                    continue;
//                }
//                StreamConfigurationMap map = cameraCharacteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
//                int deviceOrientation = getWindowManager().getDefaultDisplay().getRotation();
//                mTotalRotation = sensorToDeviceRotation(cameraCharacteristics, deviceOrientation);
//                boolean swapRotation = mTotalRotation == 90 || mTotalRotation == 270;
//                Log.e("cameraaa-rotation", ""+ mTotalRotation);
//                int rotatedWidth = width;
//                int rotatedHeight = height;
//                if(swapRotation) {
//                    rotatedWidth = height;
//                    rotatedHeight = width;
//                }
//
//                Log.e("camera.aa-height", ""+ height);
//                Log.e("cameraaa-width", ""+ width);
//                Log.e("cameraaa-Rheight", ""+ rotatedWidth);
//                Log.e("cameraaa-Rwidth", ""+ rotatedHeight);
//
//
//                mPreviewSize = chooseOptimalSize(map.getOutputSizes(SurfaceTexture.class), rotatedWidth, rotatedHeight);
//                mVideoSize = chooseOptimalSize(map.getOutputSizes(MediaRecorder.class), rotatedWidth, rotatedHeight);
//                mImageSize = chooseOptimalSize(map.getOutputSizes(ImageFormat.JPEG), rotatedWidth, rotatedHeight);
//                mImageReader = ImageReader.newInstance(mImageSize.getWidth(), mImageSize.getHeight(), ImageFormat.JPEG, 1);
//                mImageReader.setOnImageAvailableListener(mOnImageAvailableListener, mBackgroundHandler);
//
//                Log.e("camera id set up camera", cameraId);
//                mCameraId = cameraId;
//                return;
//            }
//        } catch (CameraAccessException e) {
//            e.printStackTrace();
//        }


        // Saif Work

        Context context = getApplicationContext();
        FaceDetector detector = createFaceDetector(context);

        int facing = CameraSource.CAMERA_FACING_BACK;
        if (!mIsFrontFacing) {
            facing = CameraSource.CAMERA_FACING_FRONT;
        }





        // The camera source is initialized to use either the front or rear facing camera.  We use a
        // relatively low resolution for the camera preview, since this is sufficient for this app
        // and the face detector will run faster at lower camera resolutions.
        //
        // However, note that there is a speed/accuracy trade-off with respect to choosing the
        // camera resolution.  The face detector will run faster with lower camera resolutions,
        // but may miss smaller faces, landmarks, or may not correctly detect eyes open/closed in
        // comparison to using higher camera resolutions.  If you have any of these issues, you may
        // want to increase the resolution.
        mCameraSource = new CameraSource.Builder(context, detector)
                .setFacing(facing)
                .setRequestedPreviewSize(320, 240)
                .setRequestedFps(60.0f)
                .setAutoFocusEnabled(true)
                .build();

        // Saif Work

    }


    /*
    * Saif Work
    * */

    @NonNull
    private FaceDetector createFaceDetector(final Context context) {
        Log.d(TAG, "createFaceDetector called.");

        FaceDetector detector = new FaceDetector.Builder(context)
                .setLandmarkType(FaceDetector.ALL_LANDMARKS)
                .setClassificationType(FaceDetector.ALL_CLASSIFICATIONS)
                .setTrackingEnabled(true)
                .setMode(FaceDetector.FAST_MODE)
                .setProminentFaceOnly(mIsFrontFacing)
                .setMinFaceSize(mIsFrontFacing ? 0.35f : 0.15f)
                .build();

        MultiProcessor.Factory<Face> factory = new MultiProcessor.Factory<Face>() {
            @Override
            public Tracker<Face> create(Face face) {
                return new FaceTracker(mGraphicOverlay, context, mIsFrontFacing);
            }
        };

        Detector.Processor<Face> processor = new MultiProcessor.Builder<>(factory).build();
        detector.setProcessor(processor);

        if (!detector.isOperational()) {
            Log.w(TAG, "Face detector dependencies are not yet available.");

            // Check the device's storage.  If there's little available storage, the native
            // face detection library will not be downloaded, and the app won't work,
            // so notify the user.
            IntentFilter lowStorageFilter = new IntentFilter(Intent.ACTION_DEVICE_STORAGE_LOW);
            boolean hasLowStorage = registerReceiver(null, lowStorageFilter) != null;

            if (hasLowStorage) {
                Log.w(TAG, getString(R.string.low_storage_error));
                DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                    }
                };
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(R.string.app_name)
                        .setMessage(R.string.low_storage_error)
                        .setPositiveButton(R.string.disappointed_ok, listener)
                        .show();
            }
        }
        return detector;
    }

    private void startCameraSource() {
        Log.d(TAG, "startCameraSource called.");

        // Make sure that the device has Google Play services available.
        int code = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(
                getApplicationContext());
        if (code != ConnectionResult.SUCCESS) {
            Dialog dlg = GoogleApiAvailability.getInstance().getErrorDialog(this, code, RC_HANDLE_GMS);
            dlg.show();
        }

        if (mCameraSource != null) {
            try {
                mPreview.start(mCameraSource, mGraphicOverlay);
            } catch (IOException e) {
                Log.e(TAG, "Unable to start camera source.", e);
                mCameraSource.release();
                mCameraSource = null;
            }
        }
    }


    /*
    * Saif Work
    * */
    private void connectCamera() {
        CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try{
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if(ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) ==
                        PackageManager.PERMISSION_GRANTED) {
                    //cameraManager.openCamera(mCameraId, mCameraDeviceStateCallback, mBackgroundHandler);
                    startCameraSource();
                } else {
                    if(shouldShowRequestPermissionRationale(android.Manifest.permission.CAMERA)) {
                        Toast.makeText(this,
                                "Video app required access to camera", Toast.LENGTH_SHORT).show();
                    }
                    requestPermissions(new String[] {android.Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO
                    }, REQUEST_CAMERA_PERMISSION_RESULT);
                }

            } else {
                Log.e("camera id" , mCameraId);
                cameraManager.openCamera(mCameraId, mCameraDeviceStateCallback, mBackgroundHandler);
            }
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    MediaPlayer mplayer;

    private void startRecord() {

        try {
            if(mIsRecording) {
                setupMediaRecorder();
              //  stopPlaying(mplayer);
//                Log.e("check","::::" + ListViewAdapterMainList.check);
//                Log.e("checking ","::::" + ListViewAdapterMainList.itemsUri[Integer.parseInt(urlPosition)]);

//                if(ListViewAdapterMainList.check)
//                {
//                    Log.e("check2","::::" + ListViewAdapterMainList.itemsUri[Integer.parseInt(urlPosition)]);
//                    mplayer = MediaPlayer.create(getApplicationContext(), ListViewAdapterMainList.itemsUri[Integer.parseInt(urlPosition)]);
//                    mplayer.start();
//                }
//                else{
//                    Log.e("check3","::::" + Constants.resID[ListViewAdapterIndividualSongs.intPosition]);
                    if(reqCode==1)
                    mplayer = MediaPlayer.create(getApplicationContext(),posUri);

                    else if(reqCode==2){
                    mplayer = MediaPlayer.create(getApplicationContext(), Uri.parse(pos_uri_from_uer_info_screen));
                    }

                    mplayer.start();
//                }

                long totalDuration = mplayer.getDuration(); // to get total duration in milliseconds
                Log.e("time in second--","t.duration : " + totalDuration/1000);

                long currentDuration = mplayer.getCurrentPosition(); // to Gets the current playback position in milliseconds
                Log.e("time in second--","c.duration : " + currentDuration);

//                int pos = ListViewAdapterIndividualSongs.intPosition;
//                Uri uri = Uri.parse(String.valueOf(Constants.resID[pos]));
//                MediaMetadataRetriever mmr = new MediaMetadataRetriever();
//                mmr.staSource(getApplicationContext(),uri);
//                String durationStr = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
//                int etDamillSecond = Integer.parseInt(durationStr);
//                Log.e("time in second--",": " + millSecond);
            } else if(mIsTimelapse) {
                setupTimelapse();
            }
            SurfaceTexture surfaceTexture = mTextureView.getSurfaceTexture();
            surfaceTexture.setDefaultBufferSize(mPreviewSize.getWidth(), mPreviewSize.getHeight());
            Surface previewSurface = new Surface(surfaceTexture);
            Surface recordSurface = mMediaRecorder.getSurface();
            mCaptureRequestBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
            mCaptureRequestBuilder.addTarget(previewSurface);
            mCaptureRequestBuilder.addTarget(recordSurface);

            mCameraDevice.createCaptureSession(Arrays.asList(previewSurface, recordSurface, mImageReader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(CameraCaptureSession session) {
                            mRecordCaptureSession = session;
                            try {
                                mRecordCaptureSession.setRepeatingRequest(
                                        mCaptureRequestBuilder.build(), null, null
                                );
                            } catch (CameraAccessException e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onConfigureFailed(CameraCaptureSession session) {
                            Log.d(TAG, "onConfigureFailed: startRecord");
                        }
                    }, null);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void startPreview() {
        SurfaceTexture surfaceTexture = mTextureView.getSurfaceTexture();
        surfaceTexture.setDefaultBufferSize(mPreviewSize.getWidth(), mPreviewSize.getHeight());
        Surface previewSurface = new Surface(surfaceTexture);

        try {
            mCaptureRequestBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            mCaptureRequestBuilder.addTarget(previewSurface);

            mCameraDevice.createCaptureSession(Arrays.asList(previewSurface, mImageReader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(CameraCaptureSession session) {
                            Log.d(TAG, "onConfigured: startPreview");
                            mPreviewCaptureSession = session;
                            try {
                                mPreviewCaptureSession.setRepeatingRequest(mCaptureRequestBuilder.build(),
                                        null, mBackgroundHandler);
                            } catch (CameraAccessException e) {
                                e.printStackTrace();
                            }
                        }
                        @Override
                        public void onConfigureFailed(CameraCaptureSession session) {
                            Log.d(TAG, "onConfigureFailed: startPreview");

                        }
                    }, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void startStillCaptureRequest() {
        try {
            if(mIsRecording) {
                mCaptureRequestBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_VIDEO_SNAPSHOT);
            } else {
                mCaptureRequestBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            }
            mCaptureRequestBuilder.addTarget(mImageReader.getSurface());
            mCaptureRequestBuilder.set(CaptureRequest.JPEG_ORIENTATION, mTotalRotation);

            CameraCaptureSession.CaptureCallback stillCaptureCallback = new
                    CameraCaptureSession.CaptureCallback() {
                        @Override
                        public void onCaptureStarted(CameraCaptureSession session, CaptureRequest request, long timestamp, long frameNumber) {
                            super.onCaptureStarted(session, request, timestamp, frameNumber);

                            try {
                                createImageFileName();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    };

            if(mIsRecording) {
                mRecordCaptureSession.capture(mCaptureRequestBuilder.build(), stillCaptureCallback, null);
            } else {
                mPreviewCaptureSession.capture(mCaptureRequestBuilder.build(), stillCaptureCallback, null);
            }
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void closeCamera() {
        if(mCameraDevice != null) {
            mCameraDevice.close();
            mCameraDevice = null;
        }
        if(mMediaRecorder != null) {
            mMediaRecorder.release();
            mMediaRecorder = null;
        }
    }

    private void startBackgroundThread() {
        mBackgroundHandlerThread = new HandlerThread("Camera2VideoImage");
        mBackgroundHandlerThread.start();
        mBackgroundHandler = new Handler(mBackgroundHandlerThread.getLooper());
    }

    private void stopBackgroundThread() {
        mBackgroundHandlerThread.quitSafely();
        try {
            mBackgroundHandlerThread.join();
            mBackgroundHandlerThread = null;
            mBackgroundHandler = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static int sensorToDeviceRotation(CameraCharacteristics cameraCharacteristics, int deviceOrientation) {
        int sensorOrienatation = cameraCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
        deviceOrientation = ORIENTATIONS.get(deviceOrientation);
        return (sensorOrienatation + deviceOrientation + 360) % 360;
    }

    private static Size chooseOptimalSize(Size[] choices, int width, int height) {
        List<Size> bigEnough = new ArrayList<Size>();
        for(Size option : choices) {
            if(option.getHeight() == option.getWidth() * height / width &&
                    option.getWidth() >= width && option.getHeight() >= height) {
                bigEnough.add(option);
            }
        }
        if(bigEnough.size() > 0) {
            return Collections.min(bigEnough, new CompareSizeByArea());
        } else {
            return choices[0];
        }
    }

    private void createVideoFolder() {
        File movieFile = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
        mVideoFolder = new File(movieFile, "camera2VideoImage");
        if(!mVideoFolder.exists()) {
            mVideoFolder.mkdirs();
        }
    }

    private File createVideoFileName() throws IOException {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String prepend = "VIDEO_" + timestamp + "_";
        File videoFile = File.createTempFile(prepend, ".mp4", mVideoFolder);
        mVideoFileName = videoFile.getAbsolutePath();
        return videoFile;
    }

    private void createImageFolder() {
        File imageFile = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        mImageFolder = new File(imageFile, "camera2VideoImage");
        if(!mImageFolder.exists()) {
            mImageFolder.mkdirs();
        }
    }

    private File createImageFileName() throws IOException {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String prepend = "IMAGE_" + timestamp + "_";
        File imageFile = File.createTempFile(prepend, ".jpg", mImageFolder);
        mImageFileName = imageFile.getAbsolutePath();
        return imageFile;
    }
    private void checkWriteStoragePermission() {
        int result = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if(result == PackageManager.PERMISSION_GRANTED) {
                try {
                    createVideoFileName();
                    if(mIsTimelapse || mIsRecording) {
                        startRecord();
                        mMediaRecorder.start();

                        mChronometer.setBase(SystemClock.elapsedRealtime());
                        mChronometer.setVisibility(View.VISIBLE);
                        mChronometer.start();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                if(shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    Toast.makeText(this, "app needs to be able to save videos", Toast.LENGTH_SHORT).show();
                }
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_EXTERNAL_STORAGE_PERMISSION_RESULT);
            }
        } else {
            try {
                createVideoFileName();
                if(mIsRecording || mIsTimelapse) {
                    startRecord();
                    mMediaRecorder.start();
                    mChronometer.setBase(SystemClock.elapsedRealtime());
                    mChronometer.setVisibility(View.VISIBLE);
                    mChronometer.start();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    private void setupMediaRecorder() throws IOException {
        mMediaRecorder = new MediaRecorder();
        mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        mMediaRecorder.setOutputFile(mVideoFileName);
        mMediaRecorder.setVideoEncodingBitRate(1000000);
        mMediaRecorder.setVideoFrameRate(30);
        mMediaRecorder.setVideoSize(mVideoSize.getWidth(), mVideoSize.getHeight());
        mMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        mMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        mMediaRecorder.setOrientationHint(mTotalRotation);
        mMediaRecorder.prepare();
    }

    private void setupTimelapse() throws IOException {
        mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        mMediaRecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_TIME_LAPSE_HIGH));
        mMediaRecorder.setOutputFile(mVideoFileName);
        mMediaRecorder.setCaptureRate(2);
        mMediaRecorder.setOrientationHint(mTotalRotation);
        mMediaRecorder.prepare();
    }

    private void lockFocus() {
        mCaptureState = STATE_WAIT_LOCK;
        mCaptureRequestBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START);
        try {
            if(mIsRecording) {
                mRecordCaptureSession.capture(mCaptureRequestBuilder.build(), mRecordCaptureCallback, mBackgroundHandler);
            } else {
                mPreviewCaptureSession.capture(mCaptureRequestBuilder.build(), mPreviewCaptureCallback, mBackgroundHandler);
            }
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }
    /*
     * @param videoFile path to video file
     * @param audioFile path to audiofile
     */
    public String mux(String videoFile, String audioFile) {
        Movie video = null;
        Log.e("video file" ,videoFile);
        Log.e("Audio file" ,audioFile);
        try {
            video = new MovieCreator().build(videoFile);
        } catch (RuntimeException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        Movie audio = null;
        try {
            audio = new MovieCreator().build(audioFile);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (NullPointerException e) {

            e.printStackTrace();
            return null;
        }
        int size = audio.getTracks().size();
        Track audioTrack = audio.getTracks().get((size - 1));
        video.addTrack(audioTrack);

        Container out = new DefaultMp4Builder().build(video);

        File myDirectory = new File(Environment.getExternalStorageDirectory(), "/Folder Name");
        if (!myDirectory.exists()) {

            myDirectory.mkdirs();
        }
        String filePath;
        filePath = myDirectory + "/video" + System.currentTimeMillis() + ".mp4";
        try {
            RandomAccessFile ram = new RandomAccessFile(String.format(filePath), "rw");
            Log.e("ram" , ""+ ram);
            FileChannel fc = ram.getChannel();
            out.writeContainer(fc);
            ram.close();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return mVideoFileName;
    }
    public void getSongsIntoList() {
        try{


        Cursor audioCursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, null, null, null, null);
        Log.e("uAudioCursor","" + audioCursor);
        final Uri[] musicUri = {MediaStore.Audio.Media.EXTERNAL_CONTENT_URI};
        Log.e("uUri","" + musicUri[0]);

        if(audioCursor != null){
            if(audioCursor.moveToFirst()){
                do{
                    int audioIndex = audioCursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME);
                    int audioLoc = audioCursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA);
                    audioLocation.add(audioCursor.getString(audioLoc));
                    Log.e("uAudioIndex","" + audioCursor.getString(audioIndex));
                    Log.e("uAudioLoc","" + audioCursor.getString(audioLoc));
                    audioName.add(audioCursor.getString(audioIndex));
                }while(audioCursor.moveToNext());
            }
        }
        audioCursor.close();


        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        mplayer.stop();
        mMediaRecorder.stop();
        moveTaskToBack(true);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mplayer.stop();
        mMediaRecorder.stop();
        moveTaskToBack(true);
        finish();
    }

}