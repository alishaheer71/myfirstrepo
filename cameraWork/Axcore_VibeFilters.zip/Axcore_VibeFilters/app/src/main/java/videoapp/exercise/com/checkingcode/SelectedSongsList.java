package videoapp.exercise.com.checkingcode;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

public class SelectedSongsList extends AppCompatActivity {
    public static ListView lv;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.selected_songs_list_mysounds);
        lv = findViewById(R.id.listViewId);
        ListViewAdapterMainList listViewAdapterMainList = new ListViewAdapterMainList(this,this);
        lv.setAdapter(listViewAdapterMainList);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(ListViewAdapterMainList.mp!=null)
        ListViewAdapterMainList.mp.stop();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(ListViewAdapterMainList.mp!=null)
        ListViewAdapterMainList.mp.stop();
        finish();
    }
}
