package videoapp.exercise.com.checkingcode;

import java.util.ArrayList;

public class Song {
    private String name;
    private String uri;
    private ArrayList<Song> arrayList = new ArrayList<>();

    public Song(){}

    public Song(String name, String uri){
        this.name = name;
        this.uri = uri;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public ArrayList<Song> getArrayList() {
        return arrayList;
    }

    public void setArrayList(ArrayList<Song> arrayList) {
        this.arrayList = arrayList;
    }

}
