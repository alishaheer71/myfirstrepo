package videoapp.exercise.com.checkingcode;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

public class DialogBoxUserScreen extends DialogFragment {
   public static String userName = "";

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            builder = new AlertDialog.Builder(getContext());
            builder.setTitle("User Profile");
            View viewInflated = LayoutInflater.from(getContext()).inflate(R.layout.custom_dialog_to_set_user_name, (ViewGroup) getView(), false);
// Set up the input
            final EditText fName = (EditText) viewInflated.findViewById(R.id.etFirstNameId);
            final EditText lName = (EditText) viewInflated.findViewById(R.id.etLastNameId);
// Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
            builder.setView(viewInflated);

// Set up the buttons
            builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    String fname = fName.getText().toString();
                    String lname = lName.getText().toString();
                    userName = fname + lname;
                }
            });
            builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

        }
        return builder.create();
    }
}
