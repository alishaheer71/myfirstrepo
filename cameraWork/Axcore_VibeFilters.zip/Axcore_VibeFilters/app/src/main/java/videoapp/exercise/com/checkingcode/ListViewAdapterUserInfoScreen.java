package videoapp.exercise.com.checkingcode;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class ListViewAdapterUserInfoScreen extends BaseAdapter {
    Context context;
    Activity activity;
    public static int pos;

    public ListViewAdapterUserInfoScreen(Context context,Activity activity){
        this.context = context;
        this.activity = activity;
    }

    @Override
    public int getCount() {
        return Constants.listItemsUserScreen.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        final View rowView = inflater.inflate(R.layout.single_list_item_user_screen, parent, false);
        final TextView tvListElements = (TextView) rowView.findViewById(R.id.tvSingleListItemUserScreen);
        tvListElements.setText(Constants.listItemsUserScreen[position]);
        Typeface myfont = Typeface.createFromAsset(activity.getAssets(),"fonts/OpenSans-Semibold.ttf");
        tvListElements.setTypeface(myfont);
            tvListElements.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    switch (position) {
                        case 0: {
//                            Toast.makeText(activity.getApplicationContext(),"working position:" + position,Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(activity,SelectedSongsList.class);
                            activity.startActivityForResult(intent,2);

//  Intent intent = new Intent(context,OriginalVibes.class);
//                            activity.startActivity(intent);
                            break;
                        }
                        case 1: {
                            Toast.makeText(activity.getApplicationContext(),"working position:" + position,Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(context,FadeVibes.class);
                            activity.startActivity(intent);
                            break;
                        }
                        case 2: {
                            Toast.makeText(activity.getApplicationContext(),"working position:" + position,Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(context,TrimVibes.class);
                            activity.startActivity(intent);
                            break;
                        }
                        case 3: {
                            Toast.makeText(activity.getApplicationContext(),"working position:" + position,Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(context,MergeVibes.class);
                            activity.startActivity(intent);
                            break;
                        }
                    }
                }
            });
        activity.getIntent();
        return rowView;
    }
}
