package videoapp.exercise.com.checkingcode;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.Size;
import android.view.MenuItem;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.LoadBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegNotSupportedException;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class Activity_Preview extends Activity implements TextureView.SurfaceTextureListener , View.OnClickListener {

    private MediaPlayer mMediaPlayer;
    private String fileName;
    float height,width;
    private File mVideoFolder;
    private Size mPreviewSize;
    private Boolean flag = false;
    TextureView textureView;
    ImageButton imgBtnTrim;
    ImageButton imgBtnFade;
    ImageButton imgBtnSave;
    ImageButton imgBtnDontSave;
    ImageButton imgBtnBack;
    private ProgressDialog progressDialog;

    int choice = 0;
    public Activity_Preview(){
        createVideoFolder();
        ListViewAdapterIndividualSongs.intPosition = -1;
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_preview);

        initView();

        Intent intent = getIntent();
        fileName = intent.getStringExtra("FileName");
//        fileName = "/storage/emulated/0/Movies/originalVibe/video1.mp4";
//        Log.d("filename",fileName);

        imgBtnSave.setOnClickListener(this);
        imgBtnDontSave.setOnClickListener(this);
        imgBtnTrim.setOnClickListener(this);
        imgBtnFade.setOnClickListener(this);
        imgBtnBack.setOnClickListener(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle(null);
        progressDialog.setCancelable(false);
    }

    private void initView() {
        textureView = findViewById(R.id.textureViewActPreview);
        textureView.setSurfaceTextureListener(this);
        imgBtnSave = findViewById(R.id.saveImgBtnId);
        imgBtnDontSave = findViewById(R.id.dontSaveImgBtnId);
        imgBtnTrim = findViewById(R.id.cutImgBtnId);
        imgBtnFade = findViewById(R.id.fadeImgBtnId);
        imgBtnBack = findViewById(R.id.backImgBtnId);
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int width, int height) {
        Surface s = new Surface(surfaceTexture);

        try {

            mMediaPlayer = new MediaPlayer();
            mMediaPlayer.setDataSource(fileName);
            mMediaPlayer.setSurface(s);
            mMediaPlayer.prepare();

//            mMediaPlayer.setOnBufferingUpdateListener(this);
//            mMediaPlayer.setOnCompletionListener(this);
//            mMediaPlayer.setOnPreparedListener(this);
//            mMediaPlayer.setOnVideoSizeChangedListener(this);


            mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mMediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mediaPlayer) {
                    mediaPlayer.start();
                }
            });
            mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    mMediaPlayer.start();
                }
            });
        } catch (IllegalArgumentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SecurityException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalStateException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i1) {

    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        return false;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.saveImgBtnId: {
                if (!flag) {
                    flag = true;
                    imgBtnSave.setVisibility(View.INVISIBLE);
                    Toast.makeText(getApplicationContext(), "Video has been saved", Toast.LENGTH_SHORT).show();
//                    saveVideoToLocalStorage(fileName);
                    finish();
                }
                break;
            }

            case R.id.dontSaveImgBtnId: {
                Log.d("fpath", fileName);
                if(!flag) {
                    boolean file = (new File(fileName).getAbsoluteFile().delete());
                    if (file) {
                        Log.d("true", "true");
                    }
                }
                finish();
                break;
            }

            case R.id.cutImgBtnId: {
                stopPlaying(mMediaPlayer);
                Intent intent = new Intent(this,TrimVideo.class);
                intent.putExtra("FileName",fileName);
                startActivity(intent);

                Log.e("trim", "trim");
                break;
            }

            case R.id.fadeImgBtnId: {
                stopPlaying(mMediaPlayer);
                addFadeEffect();
                break;
            }
            case R.id.backImgBtnId: {
                    if(!flag) {
                        boolean file = (new File(fileName).getAbsoluteFile().delete());
                        if (file) {
                            Log.d("true", "true");
                        }
                    }
                finish();
                break;
            }
            default: {
                Log.e("default", "default is running");
            }
        }
    }

    private void addFadeEffect() {
        loadFFMpegBinary();
        choice = 5;
        selectedVideoUri = Uri.fromFile(new File(fileName));
        if(selectedVideoUri!=null)
        executeFadeInFadeOutCommand(fileName);
    }


//    private void saveVideoToLocalStorage(String mVideoFileName) {
//        flag = true;
//        Intent mediaStoreUpdateIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
//        Toast.makeText(getApplicationContext(), "file: " + fileName, Toast.LENGTH_SHORT).show();
//        mediaStoreUpdateIntent.setData(Uri.fromFile(new File(mVideoFileName)));
//        sendBroadcast(mediaStoreUpdateIntent);
//    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopPlaying(mMediaPlayer);
    }

    private void stopPlaying(MediaPlayer mediaPlayer) {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
    }

    private FFmpeg ffmpeg;
    private static final String TAG = "Activity -- preview Tag";
    private Uri selectedVideoUri;
    private String filePath = "filepath";
    private int duration;

    public void loadFFMpegBinary() {
        try {
            if (ffmpeg == null) {
                Log.d(TAG, "ffmpeg : era nulo");
                ffmpeg = FFmpeg.getInstance(this);
            }
            ffmpeg.loadBinary(new LoadBinaryResponseHandler() {
                @Override
                public void onFailure() {
                    showUnsupportedExceptionDialog();
                }

                @Override
                public void onSuccess() {
                    Log.d(TAG, "ffmpeg : correct Loaded");
                }
            });
        } catch (FFmpegNotSupportedException e) {
            showUnsupportedExceptionDialog();
        } catch (Exception e) {
            Log.d(TAG, "EXception no controlada : " + e);
        }
    }

    private void showUnsupportedExceptionDialog() {
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Not Supported")
                .setMessage("Device Not Supported")
                .setCancelable(false)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .create()
                .show();
    }
    private void createVideoFolder() {
        File movieFile = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
        mVideoFolder = new File(movieFile, "FadeVideos");
        if(!mVideoFolder.exists()) {
            mVideoFolder.mkdirs();
        }
    }

    /**
     * Command for adding fade in fade out effect at start and end of video
     */
    private void executeFadeInFadeOutCommand(String fileName) {
        File moviesDir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_MOVIES
        );
        String filePrefix = "fade_video";
        String fileExtn = ".mp4";
        String yourRealPath = getPath(Activity_Preview.this, selectedVideoUri);


        File dest = new File(moviesDir.getAbsolutePath() + "/FadeVideos", filePrefix + fileExtn);
        int fileNo = 0;
        while (dest.exists()) {
            fileNo++;
            dest = new File(moviesDir.getAbsolutePath()  + "/FadeVideos", filePrefix + fileNo + fileExtn);
        }


        Log.d(TAG, "startTrim: src: " + yourRealPath);
        Log.d(TAG, "startTrim: dest: " + dest.getAbsolutePath());
        filePath = dest.getAbsolutePath();
        String[] complexCommand = {"-y", "-i", yourRealPath, "-acodec", "copy", "-vf", "fade=t=in:st=0:d=5,fade=t=out:st=" + String.valueOf(duration - 5) + ":d=5", filePath};
        execFFmpegBinary(complexCommand);
    }
    /**
     * Get a file path from a Uri. This will get the the path for Storage Access
     * Framework Documents, as well as the _data field for the MediaStore and
     * other file-based ContentProviders.
     */
    private String getPath(final Context context, final Uri uri) {

        final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;

        // DocumentProvider
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
                // ExternalStorageProvider
                if (isExternalStorageDocument(uri)) {
                    final String docId = DocumentsContract.getDocumentId(uri);
                    final String[] split = docId.split(":");
                    final String type = split[0];

                    if ("primary".equalsIgnoreCase(type)) {
                        return Environment.getExternalStorageDirectory() + "/" + split[1];
                    }

                    // TODO handle non-primary volumes
                }
                // DownloadsProvider
                else if (isDownloadsDocument(uri)) {
                    final String id = DocumentsContract.getDocumentId(uri);
                    final Uri contentUri = ContentUris.withAppendedId(
                            Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                    return getDataColumn(context, contentUri, null, null);
                }
                // MediaProvider
                else if (isMediaDocument(uri)) {
                    final String docId = DocumentsContract.getDocumentId(uri);
                    final String[] split = docId.split(":");
                    final String type = split[0];

                    Uri contentUri = null;
                    if ("image".equals(type)) {
                        contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    } else if ("video".equals(type)) {
                        contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    } else if ("audio".equals(type)) {
                        contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    }

                    final String selection = "_id=?";
                    final String[] selectionArgs = new String[]{
                            split[1]
                    };

                    return getDataColumn(context, contentUri, selection, selectionArgs);
                }
            }
            // MediaStore (and general)
            else if ("content".equalsIgnoreCase(uri.getScheme())) {
                return getDataColumn(context, uri, null, null);
            }
            // File
            else if ("file".equalsIgnoreCase(uri.getScheme())) {
                return uri.getPath();
            }
        }

        return null;
    }
    private boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }
    private boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is MediaProvider.
     */
    private boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }
    /**
     * Get the value of the data column for this Uri.
     */
    private String getDataColumn(Context context, Uri uri, String selection,
                                 String[] selectionArgs) {

        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {
                column
        };

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int column_index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(column_index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }
    /**
     * Executing ffmpeg binary
     */
    private void execFFmpegBinary(final String[] command) {
        try {

            ffmpeg.execute(command, new ExecuteBinaryResponseHandler() {
                @Override
                public void onFailure(String s) {
                    Log.d(TAG, "FAILED with output : " + s);
                }

                @Override
                public void onSuccess(String s) {
                    Log.d(TAG, "SUCCESS with output : " + s);
                    if (choice == 1 || choice == 2 || choice == 5 || choice == 6 || choice == 7) {
                        Intent intent = new Intent(getApplicationContext(), Activity_Fade_Effect_Preview.class);
                        intent.putExtra("filepath", filePath);
                        intent.putExtra("className","fadeactivitypreview");
                        startActivity(intent);
                    } else if (choice == 3) {
//                        Intent intent = new Intent(TrimVideo.this, PreviewImageActivity.class);
//                        intent.putExtra(FILEPATH, filePath);
//                        startActivity(intent);
                    } else if (choice == 4) {
//                        Intent intent = new Intent(TrimVideo.this, AudioPreviewActivity.class);
//                        intent.putExtra(FILEPATH, filePath);
//                        startActivity(intent);
                    } else if (choice == 8) {
                        choice = 9;
//                        reverseVideoCommand();
                    }
                }



                @Override
                public void onProgress(String s) {
                    Log.d(TAG, "Started command : ffmpeg " + command);
                    if (choice == 8)
                        progressDialog.setMessage("progress : splitting video " + s);
                    else if (choice == 9)
                        progressDialog.setMessage("progress : reversing splitted videos " + s);
                    else if (choice == 10)
                        progressDialog.setMessage("progress : concatenating reversed videos " + s);
                    else
                        progressDialog.setMessage("progress : " + "Please have patience as it'll take some time");
//                        progressDialog.setMessage("progress : " + s);
                    Log.d(TAG, "progress : " + s);
                }
                @Override
                public void onStart() {
                    Log.d(TAG, "Started command : ffmpeg " + command);
                    progressDialog.setMessage("Processing...");
                    progressDialog.show();
                }

                @Override
                public void onFinish() {
                    Log.d(TAG, "Finished command : ffmpeg " + command);
//                    if (choice != 8 && choice != 9 && choice != 10) {
                        progressDialog.dismiss();
//                    }
                }
            });
        } catch (FFmpegCommandAlreadyRunningException e) {
            // do nothing for now
        }

    }
    public static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            if (children != null) {
                for (int i = 0; i < children.length; i++) {
                    boolean success = deleteDir(new File(dir, children[i]));
                    if (!success) {
                        return false;
                    }
                }
            }
        }
        return dir.delete();
    }

}
