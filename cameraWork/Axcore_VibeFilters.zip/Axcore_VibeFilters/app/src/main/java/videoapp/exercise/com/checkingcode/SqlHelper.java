package videoapp.exercise.com.checkingcode;

import android.app.Activity;
import android.os.Bundle;

import java.util.List;

public class SqlHelper extends Activity {

    private SQLiteDatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // create our sqlite helper class
        db = new SQLiteDatabaseHandler(this);

        List<Song> players = db.allSongs();

        if (players != null) {
            String[] itemsNames = new String[players.size()];

            for (int i = 0; i < players.size(); i++) {
                itemsNames[i] = players.get(i).toString();
            }
            // display like string instances
        }
    }
}