package videoapp.exercise.com.checkingcode;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedList;
import java.util.List;

public class ListViewAdapterMainList extends BaseAdapter {
    static MediaPlayer mp;
    Context context;
    Activity activity;
    ListView listView;
    private SQLiteDatabaseHandler db;
    static String songName= "";
    static int songPosition;

    static String[] itemsNames = new String[0];
    static Uri[] itemsUri = new Uri[0];
    final static List<Song> finalSongs=null;

    Boolean flag=true;
    static Boolean check=false;

    public ListViewAdapterMainList(Context context, Activity activity){
        this.context = context;
        this.activity = activity;
        db = new SQLiteDatabaseHandler(context);
        check = false;
    }

    @Override
    public int getCount() {
        Log.e("number:","number: " + db.numberOfColumns());
        return db.allSongs().size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        List<Song> songs = new LinkedList<Song>();
        songs = db.allSongs();
        Log.d("size", "Size: " + songs.size());

        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);


        final View rowView = inflater.inflate(R.layout.single_list_item_sdcard_sounds, parent, false);
        TextView textViewSongName = rowView.findViewById(R.id.tvIdSongName);
        ImageButton ibEachListMenu = rowView.findViewById(R.id.menuOptionsListView);
        Typeface myfont = Typeface.createFromAsset(activity.getAssets(),"fonts/OpenSans-Semibold.ttf");
        textViewSongName.setTypeface(myfont);

        //        TextView textViewSelectSong = (TextView) rowView.findViewById(R.id.tvSelectSongIdIndividual);
        listView = activity.findViewById(R.id.listViewId);
        Log.e("songs", String.valueOf(songs));
        if(songs != null){
            itemsNames = new String[songs.size()];
            itemsUri = new Uri[songs.size()];
            for(int i = 0; i <songs.size(); i++){
                itemsNames[i] = songs.get(i).getName();
                Log.e("working", "getView: " + itemsUri[i]);
                itemsUri[i] = Uri.parse(songs.get(i).getUri());
            }
        }
        textViewSongName.setText(itemsNames[position]);
        //        textViewSongName.setText("");
      //        textViewSelectSong.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//            }
//        });
        final String[] finalItemsNames1 = itemsNames;
        textViewSongName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                check = true;
//                Toast.makeText(context, "working", Toast.LENGTH_SHORT).show();
//                songName = finalItemsNames1[position];
//                songPosition = position;
               MediaPlayer mplayer;
               int totalDuration=0;
               mplayer = MediaPlayer.create(activity.getApplicationContext(), itemsUri[position]);
               totalDuration = mplayer.getDuration()/1000; // to get total duration in milliseconds
               if(totalDuration<=5)
               {
                   Toast.makeText(activity.getApplicationContext(),"Song Duration is too less to select " + totalDuration,Toast.LENGTH_SHORT).show();
               }
               else if(totalDuration>=15)
               {
                   Toast.makeText(activity.getApplicationContext(),"Song Duration is too long to select ",Toast.LENGTH_SHORT).show();
               }
               else{
                   Intent returnIntent = new Intent();
                   returnIntent.putExtra("songName",finalItemsNames1[position]);
                   returnIntent.putExtra("songUri" , ""+itemsUri[position]);
//                   Toast.makeText(activity.getApplicationContext(),"song Name:: " + finalItemsNames1[position],Toast.LENGTH_SHORT).show();
//                   Toast.makeText(activity.getApplicationContext(),"song Uri:: " + itemsUri[position],Toast.LENGTH_SHORT).show();
                   activity.setResult(2,returnIntent);
//                   Log.e("activity","activity ok" + 2);
//                   Log.e("activity","activity cancel" + activity.RESULT_CANCELED);
                   activity.finish();
               }
            }
        });

        final ImageButton btnPlay = rowView.findViewById(R.id.idPlayImgBtn);
        mp = MediaPlayer.create(context, Uri.parse(songs.get(position).getUri()));

        final List<Song> finalSongs = songs;
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(flag){
                    mp = MediaPlayer.create(context,  Uri.parse(finalSongs.get(position).getUri()));
                    flag = false;
                }
                if(mp.isPlaying()){
                    mp.pause();
                    btnPlay.setImageResource(R.mipmap.play_btn);
                } else{
                    mp.stop();
                    mp = MediaPlayer.create(context,  Uri.parse(finalSongs.get(position).getUri()));
                    mp.start();
                    btnPlay.setImageResource(R.mipmap.pause_btn);
                }
            }
        });
        final String[] finalItemsNames = itemsNames;
        ibEachListMenu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(activity, view);
                popupMenu.getMenuInflater().inflate(R.menu.listview_menu_list, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                      public boolean onMenuItemClick(MenuItem menuItem){
                        int i = menuItem.getItemId();
                        if (i == R.id.delete){
                            //handle delete
                            db.deleteItemFromList(finalItemsNames[position]);
                            notifyDataSetChanged();
                            return true;
                        } else {
                            return false;
                        }
                    }
                });
                popupMenu.show();
            }
        });
        return rowView;
    }
}

