package videoapp.exercise.com.checkingcode;

import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

public class ExternalSounds extends AppCompatActivity {
    String[] proj = { MediaStore.Audio.Media._ID,MediaStore.Audio.Media.DISPLAY_NAME };
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listview_external_sounds);

        ListView audioView = findViewById(R.id.sdcardSoundsList);

        ListViewAdapterExternalSounds adapter  = new ListViewAdapterExternalSounds(this,this);
        audioView.setAdapter(adapter);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(ListViewAdapterExternalSounds.mp!=null)
            ListViewAdapterExternalSounds.mp.stop();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(ListViewAdapterExternalSounds.mp!=null)
        ListViewAdapterExternalSounds.mp.stop();
    }
}
