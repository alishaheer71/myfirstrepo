package videoapp.exercise.com.checkingcode;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.util.Log;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper{

//    public static ArrayList<String> uriList;
    public static final String DATABASE_NAME = Constants.USER_DB_NAME;
    public static final String TABLE_NAME = Constants.USER_TABLE_NAME;
    public static final String USER_SELECTED_SONG_TABLE_NAME = Constants.USER_SELECTED_SONG_TABLE_NAME;
    public static final String USER_SELECTED_SONG_COLUMN_NAME = Constants.USER_SELECTED_SONG_COLUMN_NAME;
    public static final String COLUMN_NAME = Constants.COLUMN_NAME;

    public DBHelper(Context context) {
        super(context,DATABASE_NAME,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
            Log.e("sql","working");
            sqLiteDatabase.execSQL("create table " + TABLE_NAME +
                "(NAME TEXT)"
        );

        sqLiteDatabase.execSQL("create table " + USER_SELECTED_SONG_TABLE_NAME +
                "(SONG TEXT)"
        );

    }
    public String said(){
        return "name";
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS user");
        onCreate(sqLiteDatabase);
    }

    public boolean insertName (String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from " + TABLE_NAME);
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_NAME, name);
        db.insert(TABLE_NAME, null, contentValues);
        return true;
    }

    public boolean updateName (String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        db.update(TABLE_NAME, contentValues, "name = ? ", new String[] { name } );
        return true;
    }

    public String getName(){
        String username = "";
        Cursor cursor = this.getReadableDatabase().query(
                TABLE_NAME, new String[] { COLUMN_NAME },
                null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                username = cursor.getString(0);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return username;
    }

//    public boolean insertSong (Uri song) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues contentValues = new ContentValues();
//        contentValues.put(USER_SELECTED_SONG_COLUMN_NAME , String.valueOf(song));
//        db.insert(USER_SELECTED_SONG_TABLE_NAME, null, contentValues);
//        return true;
//    }
//
//    public ArrayList<String> getSongs(){
//        Cursor cursor = this.getReadableDatabase().query(
//                USER_SELECTED_SONG_TABLE_NAME, new String[] { USER_SELECTED_SONG_COLUMN_NAME },
//                null, null, null, null, null);
//        cursor.moveToFirst();
//        int column_index = cursor.getColumnIndex("song");
//        while(!cursor.isAfterLast()){
//            uriList.add(cursor.getString(column_index)); //add the item
//            cursor.moveToNext();
//        }
//        cursor.close();
//        return uriList;
//    }
//
//    public int getCount(){
//        int i=0;
//        Cursor cursor = this.getReadableDatabase().query(
//                USER_SELECTED_SONG_TABLE_NAME, new String[] { USER_SELECTED_SONG_COLUMN_NAME },
//                null, null, null, null, null);
//        cursor.moveToFirst();
//        int column_index = cursor.getColumnIndex("song");
//        while(!cursor.isAfterLast()) {
//            i++;
//        }
//        cursor.close();
//        return i;
//    }


}
