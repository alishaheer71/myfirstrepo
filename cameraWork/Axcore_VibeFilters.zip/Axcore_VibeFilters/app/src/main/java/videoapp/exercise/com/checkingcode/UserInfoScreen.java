package videoapp.exercise.com.checkingcode;


import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class UserInfoScreen extends AppCompatActivity{
    private DrawerLayout dl;
    private ActionBarDrawerToggle abdt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final DBHelper dbHelper;
        setContentView(R.layout.user_screen);
        dl = findViewById(R.id.drawerLayoutId);

        abdt = new ActionBarDrawerToggle(this,dl,R.string.open,R.string.close);
        abdt.setDrawerIndicatorEnabled(true);
        dl.addDrawerListener(abdt);
        abdt.syncState();
//
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
//
        final NavigationView nview = findViewById(R.id.navView);

        nview.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                Log.d("my profile tag","workin bahit");
                int item_id = menuItem.getItemId();
                if(item_id == R.id.originalvibes) {
                    Log.d("my profile tag","my profilre");
                    Intent intent = new Intent(getApplicationContext(),OriginalVibes.class);
                    startActivity(intent);
                }
                else if(item_id == R.id.fadevibes){
                    Intent intent = new Intent(getApplicationContext(),FadeVibes.class);
                    startActivity(intent);
                }
                else if(item_id==R.id.trimvibes){
                    Intent intent = new Intent(getApplicationContext(),TrimVibes.class);
                    startActivity(intent);
                }
                else if(item_id==R.id.addsound){
                    Intent intent = new Intent(getApplicationContext(),ExternalSounds.class);
                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(),"Add Sound",Toast.LENGTH_SHORT).show();
               }
                return true;
            }
        });



        ListView listView = findViewById(R.id.listViewIdUserScreen);
        ImageView ivUserImage = findViewById(R.id.ivUserImageId);
        final TextView tvName = findViewById(R.id.tvNameUserScreen);

        Typeface myfont = Typeface.createFromAsset(getAssets(),"fonts/OpenSans-Semibold.ttf");
        tvName.setTypeface(myfont);
        dbHelper = new DBHelper(getApplicationContext());
        tvName.setText(dbHelper.getName());
        final String[] userName = {dbHelper.getName()};


        ivUserImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Working",Toast.LENGTH_SHORT).show();
            }
        });

        ListViewAdapterUserInfoScreen adapteruserScreen = new ListViewAdapterUserInfoScreen(this,this);
        listView.setAdapter(adapteruserScreen);

        tvName.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                openDialog();
            }

            private void openDialog() {
                  final AlertDialog.Builder builder = new AlertDialog.Builder(UserInfoScreen.this);
                  final AlertDialog dialog;
                  View view = getLayoutInflater().inflate(R.layout.custom_dialog_to_set_user_name,null);
                  final EditText etFname = view.findViewById(R.id.etFirstNameId);
                  final EditText etLname = view.findViewById(R.id.etLastNameId);
                  final Button btnSave = view.findViewById(R.id.btnIdSave);
                  builder.setView(view);
                  dialog = builder.create();
                  btnSave.setOnClickListener(new View.OnClickListener() {
                      @Override
                      public void onClick(View view) {
                          if(!etFname.getText().toString().isEmpty() && !etLname.getText().toString().isEmpty())
                          {
                            Toast.makeText(getApplicationContext(),"Your name has been changed",Toast.LENGTH_SHORT).show();
                            String fname = etFname.getText().toString();
                            String lname = etLname.getText().toString();
                            userName[0] = fname + " " + lname;
                            tvName.setText(userName[0]);
                            dialog.dismiss();
                            updateToDb(userName[0]);
                           }else{
                            Toast.makeText(getApplicationContext(),"Empty fields can't be set as Name",Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                          }
                      }

                      private void updateToDb(String username) {
                            dbHelper.insertName(username);
                      }

                  });
                  dialog.show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
//         handle arrow click here
//        if (item.getItemId() == android.R.id.home) {
//            finish(); // close this activity and return to preview activity (if there is any)
//            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
//        }
//
//        return super.onOptionsItemSelected(item);
        return abdt.onOptionsItemSelected(item) || super.onOptionsItemSelected(item);
    }

    String posUri;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Toast.makeText(getApplicationContext(),"coming in activity resuti",Toast.LENGTH_SHORT).show();
        Log.e("inside result","result inside msg");

        if(requestCode==2)
        {
            if(resultCode==2)
            {
//                int pos = ListViewAdapterIndividualSongs.intPosition;
//                stopPlaying(mplayer);
//                Log.d("","" + Uri.parse(data.getStringExtra("songUri")));
                String songName = (data.getStringExtra("songName"));
                posUri = (data.getStringExtra("songUri"));
                Intent returnIntent = new Intent();
                returnIntent.putExtra("songName",songName);
                returnIntent.putExtra("songUri" , ""+posUri);
//                Toast.makeText(getApplicationContext(),"song Name:: " +songName,Toast.LENGTH_SHORT).show();
//                Toast.makeText(getApplicationContext(),"song Uri:: " + posUri,Toast.LENGTH_SHORT).show();
                setResult(2,returnIntent);
                Log.e("activity","activity ok" + 2);
                Log.e("activity","activity cancel" + RESULT_CANCELED);
                finish();
            }
            if(resultCode==RESULT_CANCELED)
            {
                Toast.makeText(getApplicationContext(),"No Song selected",Toast.LENGTH_SHORT).show();
            }
        }
        else{

        }
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
