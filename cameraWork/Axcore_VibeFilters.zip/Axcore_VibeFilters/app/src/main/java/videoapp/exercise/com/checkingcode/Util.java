package videoapp.exercise.com.checkingcode;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

public class Util {
    Boolean flag = false;
    public static Boolean Hatt_FLAG = false;
    public static Boolean Mustache_FLAG = false;
    public static void requestPermission(Activity activity, String permission) {
        if (ContextCompat.checkSelfPermission(activity, permission)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity, new String[]{permission}, 0);
        }
    }

    public Boolean cameraFacing(){
        if(flag){
            flag = true;
        }
        else{
            flag = false;
        }
        return flag;
    }

}
