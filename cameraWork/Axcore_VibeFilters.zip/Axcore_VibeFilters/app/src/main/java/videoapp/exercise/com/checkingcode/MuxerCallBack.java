package videoapp.exercise.com.checkingcode;

public interface MuxerCallBack {

    void onSuccess();

    void onFailure(Exception error);

}
