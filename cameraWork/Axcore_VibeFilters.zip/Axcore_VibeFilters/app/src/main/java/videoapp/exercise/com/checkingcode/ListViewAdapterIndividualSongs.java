package videoapp.exercise.com.checkingcode;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static android.app.Activity.RESULT_OK;

public class ListViewAdapterIndividualSongs extends BaseAdapter{
    static MediaPlayer mp;
    int length;
    private ListView listView;
    public static int intPosition=-1;
    TextView textViewSongName;
    Boolean flag = true;

    Context context;
    Activity activity;

    public ListViewAdapterIndividualSongs(Context context,Activity activity) {
        this.context = context;
        this.activity = activity;
    }

    @Override
    public int getCount() {
        return Constants.listContent.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View rowView = inflater.inflate(R.layout.single_list_item_individual_songs, parent, false);
        textViewSongName = (TextView) rowView.findViewById(R.id.tvSongNameId);
//        TextView textViewSelectSong = (TextView) rowView.findViewById(R.id.tvSelectSongIdIndividual);
        listView = activity.findViewById(R.id.listViewIdIndividualSongs);
        textViewSongName.setText(Constants.listContent[position]);
        activity.getIntent();
        textViewSongName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                mp.stop();
//                intPosition = position;
                if(mp!=null)
                mp.stop();
                Toast.makeText(context, "" + Uri.parse(String.valueOf(Constants.resID[position])), Toast.LENGTH_SHORT).show();
                Intent returnIntent = new Intent();
                returnIntent.putExtra("songName", Constants.listContent[position]);
                returnIntent.putExtra("songUri" , ""+Constants.resID[position]);
                activity.setResult(1,returnIntent);
                Log.e("activity","activity ok" + 1);
                Log.e("activity","activity cancel" + activity.RESULT_CANCELED);
                activity.finish();
            }
        });

        Typeface myfont = Typeface.createFromAsset(activity.getAssets(),"fonts/OpenSans-Semibold.ttf");
        textViewSongName.setTypeface(myfont);

//        textViewSelectSong.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//            }
//        });

        final ImageButton btnPlay = rowView.findViewById(R.id.ImgbtnPlaySongId);
        Log.e("pos tag","pos:::" + position);
        mp = MediaPlayer.create(context, Constants.resID[position]);
        Log.e("pos tag","pos:::" + position);

        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                   if(flag){
                       mp = MediaPlayer.create(context, Constants.resID[position]);
                       flag = false;
                   }
                   if(mp.isPlaying()){
                       mp.pause();
                       btnPlay.setImageResource(R.mipmap.play_btn);
                   } else{
                       mp.stop();
                       mp = MediaPlayer.create(context,  Constants.resID[position]);
                       mp.start();
                       btnPlay.setImageResource(R.mipmap.pause_btn);
                   }
            }
        });
        return rowView;
    }
}
