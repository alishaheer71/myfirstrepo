package videoapp.exercise.com.checkingcode;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class AddSound extends AppCompatActivity{
    Button btn;
    ListView lvAddSound;
    Uri uri;
    MediaPlayer mp;
//    ArrayList<String> uriList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_sound_activity);
        initViews();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"my btn",Toast.LENGTH_SHORT).show();
                Intent intent_upload = new Intent();
                intent_upload.setType("audio/*");
                intent_upload.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent_upload,1);
            }
        });

    }

    private void initViews() {
        btn = findViewById(R.id.btnAddSoundId);
        lvAddSound = findViewById(R.id.listViewIdAddSound);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == 1){
            if(resultCode == RESULT_OK){
                //the selected audio.
                uri = data.getData();
                mp = MediaPlayer.create(getApplicationContext(), uri);
                mp.start();

                Toast.makeText(getApplicationContext(),"ext: "  + uri,Toast.LENGTH_SHORT).show();
                Log.e("toast","" + uri);

//                DBHelper dbHelper = new DBHelper(getApplicationContext());
//                dbHelper.insertSong(uri);
//                uriList = dbHelper.getSongs();
//                for(int i=0;i<dbHelper.getCount();i++){
//                    Log.e("working","" + uriList.get(i));
//                }
            }
            else{
                Toast.makeText(getApplicationContext(),"Something went wrong" + uri,Toast.LENGTH_SHORT).show();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
        Toast.makeText(getApplicationContext(),"" + uri,Toast.LENGTH_SHORT).show();
    }
}

