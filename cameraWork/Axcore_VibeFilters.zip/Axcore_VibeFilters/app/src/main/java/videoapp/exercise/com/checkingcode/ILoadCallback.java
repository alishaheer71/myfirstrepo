package videoapp.exercise.com.checkingcode;

public interface ILoadCallback {

    void onSuccess();

    void onFailure(Exception error);

}