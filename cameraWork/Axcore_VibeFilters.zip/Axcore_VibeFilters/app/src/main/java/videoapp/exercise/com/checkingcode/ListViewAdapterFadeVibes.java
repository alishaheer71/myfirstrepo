package videoapp.exercise.com.checkingcode;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.io.File;

class ListViewAdapterFadeVibes extends BaseAdapter{
    public static String[] fileListFadeVibes = new String[0];

    Activity activity;
    Context context;

    public ListViewAdapterFadeVibes(Activity activity, Context context){
        this.activity = activity;
        this.context = context;
        addFilesToArray();
    }
    private void addFilesToArray() {
        File videoFiles = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) +Constants.pathList[1]);

        if(videoFiles.isDirectory())
        {
            fileListFadeVibes=videoFiles.list();
        }

        for(int i=0;i<fileListFadeVibes.length;i++)
        {
            Log.e("Video:"+i+" File name",fileListFadeVibes[i]);
        }
    }
    @Override
    public int getCount() {
        return fileListFadeVibes.length;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        final View rowView = inflater.inflate(R.layout.single_list_item_my_vibes,viewGroup, false);
        final TextView tvListElements = (TextView) rowView.findViewById(R.id.tvListItemIdMyVibes);
        tvListElements.setText(fileListFadeVibes[i]);
        final File videoFiles = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) +"");
        tvListElements.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity,ActivityPreviewOriginalVibes.class);
                intent.putExtra("FileName",videoFiles.toString() + Constants.pathList[1] + fileListFadeVibes[i]);
                activity.startActivity(intent);
            }
        });
        return rowView;    }
}
