package videoapp.exercise.com.checkingcode;

import android.app.Activity;
import android.content.Intent;
import android.graphics.SurfaceTexture;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;

public class Activity_Fade_Effect_Preview extends Activity implements TextureView.SurfaceTextureListener , View.OnClickListener {
    TextureView textureView;
    ImageButton imgBtnSave;
    ImageButton imgBtnDontSave;
    ImageButton imgBtnBack;
    private Boolean flag = false;
    private String filePath;
    private String className;
    private MediaPlayer mMediaPlayer;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_fade_effect_preview);
        initViews();



        Intent intent = getIntent();
        filePath = intent.getStringExtra("filepath");

        imgBtnSave.setOnClickListener(this);
        imgBtnDontSave.setOnClickListener(this);
        imgBtnBack.setOnClickListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopPlaying(mMediaPlayer);
    }

    private void stopPlaying(MediaPlayer mediaPlayer) {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
    }

    private void initViews() {
        textureView = findViewById(R.id.textureViewActFadeEffectPreview);
        textureView.setSurfaceTextureListener(this);
        imgBtnBack = findViewById(R.id.backImgBtnIdFadeEffectPreview);
        imgBtnSave = findViewById(R.id.saveImgBtnIdFadeEffectPreview);
        imgBtnDontSave = findViewById(R.id.dontSaveImgBtnIdFadeEffectPreview);
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i1) {
        Surface s = new Surface(surfaceTexture);
        try {
            mMediaPlayer = new MediaPlayer();
            mMediaPlayer.setDataSource(filePath);
            mMediaPlayer.setSurface(s);
            mMediaPlayer.prepare();
//            mMediaPlayer.setOnBufferingUpdateListener(this);
//            mMediaPlayer.setOnCompletionListener(this);
//            mMediaPlayer.setOnPreparedListener(this);
//            mMediaPlayer.setOnVideoSizeChangedListener(this);
            mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mMediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mediaPlayer) {
                    mediaPlayer.start();
                }
            });
            mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    mMediaPlayer.start();
                }
            });
        } catch (IllegalArgumentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SecurityException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalStateException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i1) {

    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        return false;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.saveImgBtnIdFadeEffectPreview: {
                if(!flag)
                {
                    flag = true;
                    Toast.makeText(getApplicationContext(), "Video has been saved", Toast.LENGTH_SHORT).show();
                }
              finish();
                Intent intent = new Intent(Activity_Fade_Effect_Preview.this,MainActivity.class);
                startActivity(intent);
              break;
            }

            case R.id.dontSaveImgBtnIdFadeEffectPreview: {
                if(!flag)
                {
                    flag = true;
                    boolean file = (new File(filePath).getAbsoluteFile().delete());
                    Toast.makeText(getApplicationContext(), "Video has not been saved", Toast.LENGTH_SHORT).show();
                }
                finish();
                Intent intent = new Intent(Activity_Fade_Effect_Preview.this,MainActivity.class);
                startActivity(intent);
                break;
            }

            case R.id.backImgBtnIdFadeEffectPreview: {
                if(!flag)
                {
                    flag = true;
                    boolean file = (new File(filePath).getAbsoluteFile().delete());
                    Toast.makeText(getApplicationContext(), "Video has not been saved", Toast.LENGTH_SHORT).show();
                }
                finish();
                break;
            }
            default: {
                Log.e("default", "default of fade effect preview is running");
            }
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        moveTaskToBack(true);
        finish();
    }
}
