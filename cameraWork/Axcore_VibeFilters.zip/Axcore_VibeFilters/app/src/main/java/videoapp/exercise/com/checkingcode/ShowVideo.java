package videoapp.exercise.com.checkingcode;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class ShowVideo extends AppCompatActivity {
    private VideoView videoView;
    private Button playButton,trimVideoBtn;
    MediaController mediaC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_video);
        videoView = (VideoView) findViewById(R.id.videoViewId);
        playButton = (Button) findViewById(R.id.playVideoBtnId);
        trimVideoBtn = (Button) findViewById(R.id.trimVideoBtn);
        mediaC = new MediaController(this);

        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent intent = getIntent();
        final String fileName = intent.getStringExtra("FileName");
        final String width = intent.getStringExtra("width");
        final String height = intent.getStringExtra("height");

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("tag", String.valueOf(videoView.getDuration()));
                playButton.setVisibility(View.GONE);
                videoView.setVideoPath(fileName);
                videoView.setMediaController(mediaC);
                mediaC.setAnchorView(videoView);
                videoView.getLayoutParams().width = convertStringToNum(width);
                videoView.getLayoutParams().height = convertStringToNum(height);
                videoView.requestLayout();
                videoView.start();
            }

            private Integer convertStringToNum(String value) {
                return Integer.parseInt(value);
            }
        });
        Toast.makeText(getApplicationContext(), "working" + fileName, Toast.LENGTH_SHORT).show();
        trimVideoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ShowVideo.this,TrimVideo.class);
                intent.putExtra("width",width);
                intent.putExtra("height",height);
                intent.putExtra("FileName",fileName);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        finish();
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
        return super.onOptionsItemSelected(item);
    }
}
