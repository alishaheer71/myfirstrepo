package videoapp.exercise.com.checkingcode;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class ListViewAdapterExternalSounds extends BaseAdapter{
   static MediaPlayer mp;
    Context context;
    Activity activity;
    private SQLiteDatabaseHandler db;
    Boolean flag=true;

    public ListViewAdapterExternalSounds(Context context, Activity activity) {
        this.context = context;
        this.activity = activity;
        db = new SQLiteDatabaseHandler(context);
//        db.dropTable();
//        db.createTable();
    }

    @Override
    public int getCount() {
        return MainActivity.audioName.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {



        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);


        final View rowView = inflater.inflate(R.layout.single_list_item_sdcard_sounds, parent, false);
        final TextView textViewSongName = (TextView) rowView.findViewById(R.id.tvIdSongName);
        ImageButton imgBtn = rowView.findViewById(R.id.menuOptionsListView);
        imgBtn.setVisibility(View.GONE);
        //        TextView textViewSelectSong = (TextView) rowView.findViewById(R.id.tvSelectSongIdIndividual);

        textViewSongName.setText(MainActivity.audioName.get(position));
        activity.getIntent();

//        textViewSelectSong.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//            }
//        });

        textViewSongName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                MainActivity.selectedSong.add(String.valueOf(Uri.parse(MainActivity.audioLocation.get(position))));
//                ((BaseAdapter) SelectedSongsList.lv.getAdapter()).notifyDataSetChanged();
                String songName,songUri;
                songName = MainActivity.audioName.get(position);
                songUri = String.valueOf(Uri.parse(MainActivity.audioLocation.get(position)));
                Song song = new Song();
                song.setName(songName);
                song.setUri(songUri);
                if(!db.checkDataAlreadyExistsorNot(song.getName())){
                    Toast.makeText(context, "Song has been successfully added", Toast.LENGTH_SHORT).show();
                    db.addSong(song);
                }
                else{
                    Toast.makeText(context, "Song Already Exists", Toast.LENGTH_SHORT).show();
                }
            }
        });
        final ImageButton btnPlay = rowView.findViewById(R.id.idPlayImgBtn);
        mp = MediaPlayer.create(context, Uri.parse(MainActivity.audioLocation.get(position)));

        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(flag){
                    mp = MediaPlayer.create(context,  Uri.parse(MainActivity.audioLocation.get(position)));
                    flag = false;
                }
                if(mp.isPlaying()){
                    mp.pause();
                    btnPlay.setImageResource(R.mipmap.play_btn);
                } else{
                    mp.stop();
                    mp = MediaPlayer.create(context,  Uri.parse(MainActivity.audioLocation.get(position)));
                    mp.start();
                    btnPlay.setImageResource(R.mipmap.pause_btn);
                }
            }
        });
        return rowView;
    }

//    public void getSongsIntoList(Activity activity) {
//        Cursor audioCursor = activity.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, null, null, null, null);
//        Log.e("uAudioCursor","" + audioCursor);
//        final Uri[] musicUri = {MediaStore.Audio.Media.EXTERNAL_CONTENT_URI};
//        Log.e("uUri","" + musicUri[0]);
//
//        if(audioCursor != null){
//            if(audioCursor.moveToFirst()){
//                do{
//                    int audioIndex = audioCursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME);
//                    int audioLoc = audioCursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA);
//
//                    audioLocation.add(audioCursor.getString(audioLoc));
//                    Log.e("uAudioIndex","" + audioIndex);
//                    Log.e("uAudioLoc","" + audioLoc);
//                    audioList.add(audioCursor.getString(audioIndex));
//                }while(audioCursor.moveToNext());
//            }
//        }
//        audioCursor.close();
//    }
}

